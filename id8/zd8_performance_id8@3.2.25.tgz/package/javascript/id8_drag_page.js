'use strict';
/**
 * id8_drag_page.js (3.0) - the Speed Test page as IterioDev's Drag Timer for iDrive 8 (car-apps iteriodev_draggy 1.1.8,
 * reference copies in id8_src/): its logic and its screens, in this app's page.
 *
 * Logic (id8_src/main.js):
 *   - the timer is fed a FUSED speed (fuse.js, verbatim): wheel speed (Vehicle2) + longitudinal acceleration (CDS2)
 *     + GPS ground speed (GPSData, ~1 Hz, when the car has it) -> a low-lag speed that rides the accel through
 *     wheelspin and calibrates the tyre / speedo bias out
 *   - every 50 ms: the latest wheel + accel (+ gps) into the fuser, fuser.tick(), the fused speed into the run timer
 *     (timer.js, verbatim: arms at a standstill, splits interpolated), timer.idle()
 *   - units (km/h | mph) and the distance (1/8 mile, 1/4 mile, 1000 m) are picked with tabs on the page and kept
 *     with the best times in data/id8_draggy.json (the ID8 app's store); no one-foot rollout
 * Screens (id8_src/screens.json, 2880 x 960, scaled into the page):
 *   home   run time + speed (big), the run's speed over time, the state line, the sensors line; the splits table
 *          (split | this run | best), unit tabs, distance tabs, Reset run, Best times
 *   bests  "Best times", the table (split | time | trap speed | when), Back
 * Wheel speed and acceleration come from the app's one Car (kit/car.js: the same signals and BMW scalings the ID8 app
 * reads); the timer runs whatever page is shown.
 */
const fs = require('fs');
const path = require('path');
const { withAlpha, mix } = require('./kit/canvas');
const G = require('./kit/gauges');
const { getLanguage } = require('./kit/i18n');
const { RunTimer } = require('./timer');
const { Fuser } = require('./fuse');

const MPH = 1.609344, G0 = 9.80665;
const SPLITS = {
    kmh: [{ key: '0-50', label: '0-50 km/h', from: 0, to: 50 }, { key: '0-100', label: '0-100 km/h', from: 0, to: 100 },
        { key: '100-200', label: '100-200 km/h', from: 100, to: 200 }, { key: '0-200', label: '0-200 km/h', from: 0, to: 200 }],
    mph: [{ key: '0-30mph', label: '0-30 mph', from: 0, to: 30 * MPH }, { key: '0-60mph', label: '0-60 mph', from: 0, to: 60 * MPH },
        { key: '60-130mph', label: '60-130 mph', from: 60 * MPH, to: 130 * MPH }, { key: '0-100mph', label: '0-100 mph', from: 0, to: 100 * MPH }],
};
const DIST = {
    qm: { key: 'qm', label: '1/4 mile', dist: 402.336 }, em: { key: 'em', label: '1/8 mile', dist: 201.168 }, m1000: { key: 'm1000', label: '1000 m', dist: 1000 },
};
const UNIT_OPTS = ['kmh', 'mph'], DIST_OPTS = ['em', 'qm', 'm1000'];
const TICK_MS = 50;

// the ID8 design (2880 x 960) into the page: x 58..2824 -> 24..1576, y 100..830 -> 54..~510
// (iDrive 8: the page is wider, SX follows its width - set by draw() - so the design spans the screen as in the original)
let SX = 1552 / 2766;
const SY = 0.625, FS = 0.6;
const bx = (x) => 24 + (x - 58) * SX, by = (y) => 54 + (y - 100) * SY, bw = (w) => w * SX, bh = (h) => h * SY, fz = (s) => Math.round(s * FS);
const box = (x, y, w, h) => ({ x: bx(x), y: by(y), w: bw(w), h: bh(h) });

const zh = () => getLanguage() === 'zh-CN';
const L = (en, cn) => (zh() ? cn : en);

/* ---------- the ID8 renderer's widgets (renderer/widgets.js, gpu.js), on this kit's canvas ---------- */
/** button: 'primary' (filled accent), 'secondary' (panel), 'outline' (accent edge); the accent is the ID8 screens'
 * theme's (m_red): M red, whatever this app's theme (its accent can be white: white text on white) */
function button(cv, t, b, o, run, key) {
    const acc = t.crit || '#ef2b2d', r = Math.min(o.radius == null ? 16 : o.radius, b.h / 2), sz = o.size;
    let fg = t.text;
    if (o.style === 'primary') { cv.card(b.x, b.y, b.w, b.h, r, [[0, mix(acc, '#ffffff', 0.12)], [1, mix(acc, '#000000', 0.22)]]); fg = '#ffffff'; }
    else if (o.style === 'secondary') { cv.roundRect(b.x, b.y, b.w, b.h, r, withAlpha(t.panelTop, 0.9)); cv.strokeRoundRect(b.x, b.y, b.w, b.h, r, 2, t.panelEdge); }
    else if (o.style === 'outline') { cv.roundRect(b.x, b.y, b.w, b.h, r, withAlpha(acc, 0.08)); cv.strokeRoundRect(b.x, b.y, b.w, b.h, r, 2, acc); fg = acc; }
    cv.text(o.text, b.x + b.w / 2, b.y + b.h / 2 + sz * 0.36, sz, fg, { align: 'center', font: 'bold' });
    if (cv.own && run) cv.target(b.x, b.y, b.w, b.h, run, key);
}
/** joined tabs, the selected one lit; a tap picks one */
function tabs(cv, t, b, items, sel, sz, pick, key) {
    const acc = t.accent, cw = b.w / items.length, r = Math.min(12, b.h / 2);
    cv.roundRect(b.x, b.y, b.w, b.h, r, withAlpha(t.panelBottom, 0.92));
    cv.strokeRoundRect(b.x, b.y, b.w, b.h, r, 1.5, t.panelEdge);
    items.forEach((s, i) => {
        const x = b.x + i * cw, on = i === sel;
        if (on) { cv.card(x, b.y, cw, b.h, r, [[0, withAlpha(acc, 0.32)], [1, withAlpha(acc, 0.12)]]); cv.strokeRoundRect(x, b.y, cw, b.h, r, 2, acc); }
        else if (i) cv.fillRect(x, b.y + b.h * 0.22, 1.5, b.h * 0.56, t.panelEdge);
        cv.text(s, x + cw / 2, b.y + b.h / 2 + sz * 0.36, sz, on ? t.text : t.dim, { align: 'center', font: on ? 'bold' : 'label' });
        if (cv.own) cv.target(x, b.y, cw, b.h, () => pick(i), key + i);
    });
}
/** table: the columns spread evenly, the first left, the rest right (gpu.js table) */
function table(cv, t, b, columns, rows, o) {
    const w = b.w / columns.length;
    G.table(cv, t, b.x, b.y, b.w, columns.map((label, i) => ({ label, w, align: i ? 'right' : 'left' })), rows,
        { size: o.size, rowH: o.rowH, headerSize: o.headerSize });
}

function create(ctx, car, repaint) {
    const { log } = ctx;

    /* ---------- store: units, distance, best times (as the ID8 app's draggy.json) ---------- */
    const FILE = path.join(ctx.dataDir, 'id8_draggy.json');
    let store = { units: 'kmh', distance: 'qm', best: {} };
    try { store = Object.assign(store, JSON.parse(fs.readFileSync(FILE, 'utf8'))); } catch (e) { /* defaults */ }
    const save = () => { if (demo) return; try { fs.writeFileSync(FILE, JSON.stringify(store)); } catch (e) { log.warn('id8 drag store: ' + e); } };

    /* ---------- sources + fusion ---------- */
    const fuse = new Fuser();
    let speedKmh = 0, demo = false, dropLogged = false;
    const raw = { gps: null };
    let gpsLink = 'connecting';
    // GPS ground speed (~1 Hz): only as calibration / anchor; its scale is unknown, the fuser rejects a wrong one
    if (ctx.signals && ctx.signals.watch) {
        ctx.signals.watch('de.bmw.infotainment.GPSData', '1', {
            GPSPositionExtendedCAN: (x) => {
                if (x && typeof x.speedGPSCAN === 'number') raw.gps = { v: x.speedGPSCAN, q: x.statusQualityPositionGPSCAN, t: Date.now() };
            },
        }, log, { pollMs: 1000 }).then((s) => { gpsLink = s && s.error ? 'ERR' : 'ok'; log.info('id8 drag: gps ' + (s && s.error ? 'error ' + s.error : 'subscribed')); })
            .catch((e) => { gpsLink = 'ERR'; log.warn('id8 drag gps: ' + e); });
    }

    /* ---------- timer ---------- */
    const splitsNow = () => SPLITS[store.units].concat([DIST[store.distance] || DIST.qm]);
    let timer = null;
    function onDone(run) {
        Object.keys(run.result).forEach((k) => {
            const b = store.best[k];
            if (!b || run.result[k] < b.s) store.best[k] = { s: run.result[k], at: run.at, trap: run.trap[k] };
        });
        save();
        log.info('id8 drag run done: ' + Object.keys(run.result).map((k) => k + ' ' + run.result[k].toFixed(2)).join(' ') + ' | vmax ' + run.vmax.toFixed(0));
    }
    const newTimer = () => { timer = new RunTimer(splitsNow(), { onDone }); };
    newTimer();

    // every 50 ms, as the ID8 app: the latest values in (their time = now: the ID8 app polls the getters), fuse, feed
    setInterval(() => {
        const now = Date.now(), d = car.data();
        if (!!d.demo !== demo) { demo = !!d.demo; fuse.reset(); newTimer(); }
        if (G.isNum(d.speed)) fuse.wheel(d.speed, now);
        if (G.isNum(d.gLong)) fuse.accel(d.gLong * G0, now);
        if (raw.gps && (raw.gps.q === undefined || raw.gps.q < 1000)) fuse.gps(raw.gps.v, true, raw.gps.t);
        const s = fuse.tick(now);
        const drop = fuse.offSince !== null && !fuse.spin;
        if (drop && !dropLogged) log.info('id8 drag: wheel speed ignored (dropout): reads ' + (G.isNum(d.speed) ? d.speed.toFixed(1) : '--') + ' km/h, fused ' + s.vKmh.toFixed(1) + ' km/h');
        dropLogged = drop;
        speedKmh = s.vKmh;
        timer.feed(s.t, s.vKmh);
        timer.idle(now);
    }, TICK_MS);

    /* ---------- what the screens show (id8_src/main.js) ---------- */
    const V = (k) => (store.units === 'mph' ? k / MPH : k);
    const vU = () => (store.units === 'mph' ? 'mph' : 'km/h');
    const secs = (s) => (s === undefined ? '-' : s.toFixed(2) + ' s');
    const when = (ms) => { const d = new Date(ms); const p = (n) => (n < 10 ? '0' : '') + n; return p(d.getDate()) + '.' + p(d.getMonth() + 1) + '. ' + p(d.getHours()) + ':' + p(d.getMinutes()); };

    function statusText() {
        const st = timer.state, el = timer.elapsed(Date.now());
        if (st === 'run') return L('Launched - timing', '已起步，计时中');
        if (st === 'ready') return L('Ready - go!', '已就绪，起步！');
        if (Object.keys(timer.result).length) return L('Run: ' + el.toFixed(2) + ' s to ' + V(timer.vmax).toFixed(0) + ' ' + vU(), '本次：' + el.toFixed(2) + ' s，到 ' + V(timer.vmax).toFixed(0) + ' ' + vU());
        return L('Stop, then launch - arms itself', '停车后起步，自动准备');
    }
    function sourceText() {
        const st = fuse.status(Date.now());
        const parts = [];
        if (st.wheel) parts.push(L('wheel', '车轮')); if (st.accel) parts.push(L('accel', '加速度')); if (st.gps) parts.push('GPS');
        let s = parts.length ? parts.join('+') : L('no sensors', '无传感器');
        if (st.gps) s += ' · cal ' + st.cal.toFixed(2);
        if (st.spin) s += L(' · WHEELSPIN', ' · 打滑');
        if (demo) s += L(' · DEMO', ' · 演示');
        return L('Sensors: ', '传感器：') + s + (gpsLink === 'ERR' ? L(' · no gps', ' · 无 GPS') : '');
    }
    function splitRows() {
        return splitsNow().map((s) => {
            const tt = timer.result[s.key], trap = timer.trapSpeed[s.key], best = store.best[s.key];
            const trapTxt = s.dist && trap !== undefined ? ' @ ' + Math.round(V(trap)) + ' ' + vU() : '';
            return [s.label, tt !== undefined ? secs(tt) + trapTxt : '-', best ? secs(best.s) : '-'];
        });
    }
    function bestRows() {
        const rows = [];
        for (const u of UNIT_OPTS) {
            for (const s of SPLITS[u].concat(UNIT_OPTS.indexOf(u) === 0 ? DIST_OPTS.map((k) => DIST[k]) : [])) {
                const b = store.best[s.key];
                if (!b) continue;
                rows.push([s.label, secs(b.s), b.trap ? Math.round(V(b.trap)) + ' ' + vU() : '-', when(b.at)]);
            }
        }
        return rows.length ? rows : [[L('No runs yet', '暂无记录'), '-', '-', '-']];
    }
    function chartOpts() {
        const tr = timer.trace, last = tr[tr.length - 1];
        const up = (v, step) => Math.ceil(v / step) * step;
        // the speed axis is fixed 0-150 km/h (100 mph, user): a faster run is drawn up to the top line (the timing
        // itself is unchanged - a 1/4 mile or 1000 m still runs to its end)
        const top = store.units === 'mph' ? 100 : 150;
        return {
            pts: tr.map(([s, v]) => [s, Math.min(top, V(v))]),
            xMax: Math.max(15, up(last ? last[0] : 0, 5)),
            yMax: top,
        };
    }

    /* ---------- screens ---------- */
    let screen = 'home';
    const setUnits = (i) => { if (UNIT_OPTS[i] && UNIT_OPTS[i] !== store.units) { store.units = UNIT_OPTS[i]; save(); newTimer(); } return repaint(); };
    const setDist = (i) => { if (DIST_OPTS[i] && DIST_OPTS[i] !== store.distance) { store.distance = DIST_OPTS[i]; save(); newTimer(); } return repaint(); };
    const resetRun = () => { timer.reset(); return repaint(); };
    const showBests = () => { screen = 'bests'; return repaint(); };
    const showHome = () => { screen = 'home'; return repaint(); };

    function drawHome(cv, t) {
        const now = Date.now();
        // run time + speed (readouts)
        let b = box(58, 110, 555, 242);
        // the big run time stops at 100 (km/h, or mph in mph): it shows that split's time from then on, while the run
        // itself goes on (the splits on the right, 100-200, 0-200, the distance, keep timing)
        const stopAt = timer.result[store.units === 'mph' ? '0-100mph' : '0-100'];
        G.readout(cv, t, b.x, b.y, { label: L('Run time', '计时'), value: stopAt !== undefined ? stopAt : timer.elapsed(now), unit: 's', decimals: 2, size: fz(170), labelSize: fz(30) });
        b = box(647, 110, 562, 242);
        G.readout(cv, t, b.x, b.y, { label: L('Speed', '车速'), value: Math.max(0, Math.round(V(speedKmh))), unit: vU(), decimals: 0, size: fz(170), labelSize: fz(30) });
        // the run's speed over time
        b = box(58, 400, 1178, 224);
        const c = chartOpts();
        // its unit above the axis labels (the kit's chart puts it at the top label's height)
        cv.text(vU(), b.x + 36, b.y + 12, 14, t.dim, { align: 'right', font: 'bold' });
        G.chart(cv, t, b.x, b.y, b.w, b.h, { xMin: 0, xMax: c.xMax, yMin: 0, yMax: c.yMax, xUnit: 's', padTop: 24,
            series: [{ pts: c.pts, color: t.accent, width: 3, fill: 0.18 }], empty: L('Launch to draw speed over time', '起步后绘制车速曲线') });
        // state + sensors
        b = box(58, 662, 1178, 60);
        const st = timer.state;
        cv.text(statusText(), b.x, b.y + fz(44) * 0.9, fz(44), st === 'ready' ? (t.go || '#2fd27a') : t.text, { font: 'label' });
        b = box(58, 740, 1178, 50);
        cv.text(sourceText(), b.x, b.y + fz(28) * 0.9, fz(28), t.dim, { font: 'label' });
        // splits, units, distance, buttons
        table(cv, t, box(1302, 110, 1522, 400), [L('Split', '分段'), L('Time', '本次'), L('Best', '最佳')], splitRows(), { size: fz(36), rowH: bh(66), headerSize: fz(26) });
        tabs(cv, t, box(1302, 540, 622, 84), ['km/h', 'mph'], UNIT_OPTS.indexOf(store.units), fz(32), setUnits, 'id8_unit');
        tabs(cv, t, box(1969, 540, 855, 84), ['1/8 mile', '1/4 mile', L('1000 m', '1000 米')], DIST_OPTS.indexOf(store.distance), fz(32), setDist, 'id8_dist');
        button(cv, t, box(1302, 714, 734, 76), { text: 'Reset run', style: 'secondary', size: fz(32) }, resetRun, 'id8_reset');
        button(cv, t, box(2091, 714, 733, 76), { text: 'Best times', style: 'primary', size: fz(32) }, showBests, 'id8_bests');
    }

    function drawBests(cv, t) {
        const b = box(58, 100, 1666, 80);
        cv.text('Best times', b.x, b.y + fz(60) * 0.85, fz(60), t.text, { font: 'bold' });
        table(cv, t, box(58, 200, 2766, 530), [L('Split', '分段'), L('Time', '成绩'), L('Trap speed', '出线车速'), L('When', '时间')], bestRows(), { size: fz(34), rowH: bh(60), headerSize: fz(26) });
        button(cv, t, box(58, 752, 622, 76), { text: 'Back', style: 'outline', size: fz(32) }, showHome, 'id8_back');
    }

    return {
        draw(cv, t) { SX = ((cv.w || 1600) - 48) / 2766; (screen === 'home' ? drawHome : drawBests)(cv, t); },
        badges() { return [demo ? { text: 'DEMO' } : null]; },
        /** The HMI bar's button (standard layout): Reset run on home, Back on the best times. */
        action() { return screen === 'home' ? resetRun() : showHome(); },
        actionLabel() { return screen === 'home' ? 'Reset run' : 'Back'; },
        /** Leaving the page, or its tab tapped again: the home screen. */
        showRun() { screen = 'home'; },
        get view() { return screen; },
        get timer() { return timer; },
        get store() { return store; },
        get speed() { return speedKmh; },
        fuse,
    };
}

module.exports = { create, SPLITS, DIST };
