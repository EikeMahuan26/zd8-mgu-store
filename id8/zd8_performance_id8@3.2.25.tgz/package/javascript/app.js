// ZD8 · Performance
'use strict';
/**
 * ZD8 Performance Tuning 3.0 - 2.0 (2.3.0) with the Speed Test page replaced by IterioDev's ID8 Drag Timer, its logic
 * (fused wheel + accel + GPS speed, fuse.js) and its screens (id8_drag_page.js); everything else as 2.0. For the BMW MGU
 * (iDrive 7):
 *
 *   Performance & Exhaust  the engine map 1-4 (read back from the DME) and the exhaust flap Open / Close / OEM side by
 *                 side, laid out as the left two cards of IterioDev's Live Adjustments (ID8); the same requests
 *   Burbles & Sound  (2.1) the burble aggression 0-12 (- / +, Apply, read back; Off) and Active Sound Design
 *                 on / off side by side, the same two-card layout
 *   Dyno          (马力机) power and torque from a full-throttle pull, saved runs, a baseline (dyno_page.js)
 *   Speed Test    (测速, 3.0) the ID8 Drag Timer: run time + speed, speed over time, state + sensors, splits table,
 *                 unit / distance tabs, Reset run, Best times -> the best times table (id8_drag_page.js, fuse.js, timer.js)
 *   Transmission  the ZF 8HP live page of Transmission Config: oil, gear, shaft speeds, temperature trace,
 *                 mechatronics (egs_page.js, read-only 22 reads of EGS 0x18 while the page is shown)
 *   Shift         (换挡, 3.2) Redline's tach with the shift lights, gear, cold-engine rev guard and, behind the "Shift log"
 *                 button top right, its Shift log (tach_page.js, as in 2.0's Tach page)
 *   Gauges        (仪表, 3.0) the ID8 Car Data engine screen: engine speed + boost bars, oil / coolant / intake air /
 *                 battery, speed + gear, power + torque bars (gauges_page.js, obd.js)
 *
 * One Car (kit/car.js) feeds every page; the page tabs are the kit's header with the large tab style
 * (app.json "tabs": "large", display.js); Settings is the header's last tab. "Tuning software" = Off
 * sends nothing to the DME at all; MHD is not offered.
 */
const mgu = require('./kit/mgu');
const G = require('./kit/gauges');
const Car = require('./kit/car');
const { DiagLink } = require('./diaglink');
const { TuneControl } = require('./tune');
const TunePages = require('./tune_pages');
const Dyno = require('./dyno_page');
const Egs = require('./egs_page');
const Tach = require('./tach_page');         // 3.2: the Shift page (换挡): Redline's tach + Shift log
const Gauges = require('./gauges_page');    // 3.0: the ID8 Car Data engine screen, in place of the Tach
const Drag = require('./id8_drag_page');     // 3.0: the ID8 Drag Timer (logic + screens)
const Widget = require('./widget');

const W = 1600, H = 520;
// 2.0: Power Map + Exhaust Flap are one page, Performance & Exhaust (tune_pages.js drawPerfExhaust)
// 2.1: Burbles + Active Sound are one page too, Sound (tune_pages.js drawSound)
// 2.3: Virtual Dyno is "Dyno" (马力机); Speed Test (测速, Drag Timer's pages, drag_page.js) between it and Transmission
const PAGES = ['Performance & Exhaust', 'Burbles & Sound', 'Dyno', 'Speed Test', 'Transmission', 'Shift', 'Gauges'];
const MAP = 0, SOUND = 1, DYNO = 2, DRAG = 3, EGS = 4, SHIFT = 5, GAUGES = 6;
const TUNE_PAGE = { [MAP]: 'perf', [SOUND]: 'sound' };

mgu.run({
    async start(ctx) {
        const { ui, settings, log } = ctx;
        // every signal the pages read: rpm + temperatures (tach), speed, acceleration + torque (dyno), gear (tach, dyno)
        const car = new Car(ctx, ['rpm', 'speed', 'temps', 'accel', 'gear', 'torque']);
        let page = MAP;
        let loop = null;
        const repaint = () => (loop && loop.kick ? loop.kick() : render());

        /* ---------- ZD8/BM3 (pages 1 and 2) ---------- */
        const tune = new TuneControl(ctx);
        // a tune action: repaint at once (shows "Sending…"), then again with the DME's answer
        const tuneAct = (fn) => () => { const p = fn(); repaint(); return Promise.resolve(p).then(repaint).catch((e) => log.error('tune', e)); };
        const acts = {
            map: (n) => tuneAct(() => tune.setMap(n)),
            aggDown: () => { tune.stepAggression(-0.5); repaint(); },
            aggUp: () => { tune.stepAggression(0.5); repaint(); },
            burblesApply: tuneAct(() => tune.applyBurbles(false)),
            burblesOff: tuneAct(() => tune.applyBurbles(true)),
            flap: (mode) => tuneAct(() => tune.setFlap(mode)),
            asd: (on) => tuneAct(() => tune.setAsd(on)),
        };
        let link = null;
        const tuneBadges = (t) => {
            const v = tune.view();
            if (!v.armed) return [{ text: 'OFF', color: t.dim }];
            if (!v.linked) return [{ text: 'NO LINK', color: t.warn }];
            return v.verified ? [] : [{ text: 'DME ?', color: t.warn }];     // 1.1.1: no green ZD8/BM3 badge
        };

        /* ---------- the other pages ---------- */
        const dyno = Dyno.create(ctx, car, repaint);
        const egs = Egs.create(ctx, car, repaint);
        // the gauges' OBD reads go through the same diagnostic link, never while a tune command is on its way
        const gauges = Gauges.create(ctx, car, () => link, () => tune.busy);
        const drag = Drag.create(ctx, car, repaint);
        const tach = Tach.create(ctx, car, repaint);
        // 2.2: the home-screen widget (map, flap, burbles, rpm, oil, coolant; sends nothing to the car)
        Widget.create(ctx, car, tune, gauges);
        // the EGS is read only while its page shows on a visible screen
        const egsActive = () => {
            egs.setActive(ui.isVisible('MAIN') && page === EGS);
            gauges.setActive(ui.isVisible('MAIN') && page === GAUGES);   // the gauges' OBD runs only while their page shows
        };

        /* ---------- drawing ---------- */
        const render = async () => {
            const t = ctx.theme();
            // iDrive 8: the page is wider (display.pageW, the whole screen width), every page lays out to cv.w
            const cv = ctx.canvas(ctx.display && ctx.display.pageW ? ctx.display.pageW() : W, H).clear(t.bg);
            let badges = [];
            if (TUNE_PAGE[page]) {
                TunePages.draw(cv, G, t, TUNE_PAGE[page], tune.view(), acts);
                badges = tuneBadges(t);
            } else if (page === DYNO) { dyno.draw(cv, t); badges = dyno.badges(t); }
            else if (page === DRAG) { drag.draw(cv, t); badges = drag.badges(t); }
            else if (page === EGS) egs.draw(cv, t);      // 1.2.1: no badges (the "LIVE" one could not be pressed)
            else if (page === SHIFT) { tach.draw(cv, t); badges = tach.badges(t); }
            else { gauges.draw(cv, t); badges = gauges.badges(t); }
            // the page tabs: in the header (large style) where the kit runs the screen, a slim tab bar otherwise
            G.frame(cv, t, PAGES, page, badges);
            await ui.image('MAIN_GFX', cv);
        };
        loop = ctx.loop('MAIN', 15, render);

        /* ---------- pages, buttons ---------- */
        // the HMI bar's action button (standard layout; left out where the kit runs the screen, the page has its own)
        const actionLabel = () => [tune.armed ? 'Next map' : 'Action', 'Apply',
            dyno.actionLabel(), drag.actionLabel(), 'Next item', tach.actionLabel(), 'Action'][page];
        const labels = () => ui.text('BTN_ACTION', actionLabel());
        const setPage = (i) => {
            if (page === DRAG) drag.showRun();      // leaving the Speed Test: it opens on the live run next time
            if (page === SHIFT) tach.showTach();    // leaving the Shift page: it opens on the tach next time
            page = ((i % PAGES.length) + PAGES.length) % PAGES.length;
            egsActive();
            labels();
            return render();
        };
        ui.onClick('BTN_PAGE', () => setPage(page + 1));
        ui.onClick('BTN_PREV', () => setPage(page - 1));
        // a header tab (touch or the controller): that page; the Transmission tab tapped again reads its data again
        ctx.onTab((i, closedSheet) => {
            if (i !== page) return setPage(i);
            if (!closedSheet && page === EGS) egs.refresh();
            if (!closedSheet && page === DRAG) { drag.showRun(); return render(); }    // the Speed Test tab again: the live run
            if (!closedSheet && page === SHIFT) { tach.showTach(); return render(); }  // the Shift tab again: back from the Shift log
            return null;
        });
        ctx.hideButton('BTN_ACTION');
        ui.onClick('BTN_ACTION', () => {
            if (page === MAP) return tune.armed ? acts.map(((tune.view().map || 0) % 4) + 1)() : null;
            if (page === SOUND) return acts.burblesApply();
            if (page === DYNO) return dyno.action();
            if (page === DRAG) return drag.action();
            if (page === EGS) return egs.nextMetric();
            if (page === SHIFT) return tach.action();
            return null;
        });
        ui.onVisible((name) => { if (name === 'MAIN') egsActive(); });
        // the tune is looked at again only when its setting changes (a theme change sends nothing)
        settings.onChange((key) => {
            if (key === 'tuner') tune.refresh().then(repaint).catch((e) => log.error('settings', e));
            labels();
        });

        /* ---------- the diagnostic link (DME 0x12 for ZD8/BM3) ---------- */
        try {
            link = await new DiagLink(ctx.signals, log).init();
        } catch (e) {
            log.warn('diag init: ' + String(e && e.message || e));
        }
        await tune.start(link);          // nothing at all while "Tuning software" is Off
        // the diagnostic link often comes up after the app started (at boot): identify the ROM again then
        if (link) link.onAvailable(() => tune.refresh().then(repaint).catch((e) => log.error('link', e)));
        egsActive();
        labels();
        await render();
        log.info('performance tuning ready (tuner=' + tune.tuner + ', link=' + !!(link && link.available) + ')');
    },
});
