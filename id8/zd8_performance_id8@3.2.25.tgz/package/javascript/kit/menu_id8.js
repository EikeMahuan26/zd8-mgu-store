'use strict';
/**
 * menu_id8.js - an app's "menu" screens on iDrive 8. iDrive 7 shows them as the HMI's own lists; iDrive 8's host state
 * has only a title (build.py id8_ui), so without this such a screen opens empty (Doom: no Play button).
 *
 * Each menu screen gets a Display of its own, as if it were a canvas screen, so the renderer draws it full screen with
 * the kit's header, touch and controller: its text rows at the top and its buttons in a grid. A button presses its
 * (virtual) component, so the app's ui.onClick works unchanged; ui.text and ui.visible on the rows are read back from
 * the Ui. A menu with "settings": true has the Settings tab.
 */
const { Display } = require('./display');
const G = require('./gauges');
const { pill } = require('./sheet');

const TOP = 50, BOTTOM = 512, GAP = 14;

class MenuPage {
    constructor(ui, log, spec, settings, theme, screen) {
        this.ui = ui; this.log = log; this.theme = theme; this.screen = screen;
        const buttons = screen.settings && (spec.settings || []).length ? [['BTN_SETTINGS', 'Settings']] : [];
        this.d = new Display(ui, log, Object.assign({}, spec, {
            screens: [{ name: screen.name, kind: 'canvas', title: screen.title, graphic: screen.name + '_GFX', buttons }],
        }), settings, theme);
        this.timer = null;
        ui.onVisible((name, v) => { if (name === screen.name) this._run(v); });
        if (ui.isVisible(screen.name)) this._run(true);
    }
    _run(on) {
        if (on && !this.timer) this.timer = setInterval(() => this.draw(), 250);
        if (!on && this.timer) { clearInterval(this.timer); this.timer = null; }
    }
    /** The rows that show now: { kind, name, label } */
    rows() {
        const ui = this.ui;
        return (this.screen.items || []).map((it) => {
            const set = ui._labels && it[1] in ui._labels;
            return { kind: it[0], name: it[1], label: String((set ? ui._labels[it[1]] : it[2]) || '') };
        }).filter((r) => r.label.trim() && !(ui._hidden && ui._hidden[r.name]));
    }
    /** A paragraph cut into lines that fit w */
    wrap(cv, text, size, w) {
        const out = [];
        String(text).split('\n').forEach((para) => {
            let line = '';
            para.split(' ').forEach((word) => {
                const next = line ? line + ' ' + word : word;
                if (line && cv.textWidth(next, size, { font: 'bold' }) > w) { out.push(line); line = word; } else line = next;
            });
            if (line) out.push(line);
        });
        return out;
    }
    draw() {
        const d = this.d, name = this.screen.name;
        if (!d.active(name) || d.sheet) return;
        const t = this.theme(), W = d.pageW();
        const cv = d.canvas(W, 520).clear(t.bg);
        const rows = this.rows(), btns = rows.filter((r) => r.kind === 'button'), texts = rows.filter((r) => r.kind !== 'button');
        const bottom = BOTTOM + (cv.extra || 0), left = 60, width = W - 2 * left;
        let y = TOP + 34;
        const maxText = btns.length ? 5 : 11;
        let shown = 0;
        texts.forEach((r) => {
            this.wrap(cv, r.label, 30, width).forEach((l) => {
                if (shown++ >= maxText) return;
                cv.text(l, left, y, 30, t.text, { font: 'bold' });
                y += 42;
            });
        });
        if (btns.length) {
            const cols = btns.length > 8 ? 3 : btns.length > 3 ? 2 : 1, lines = Math.ceil(btns.length / cols);
            let top = y + (texts.length ? 8 : 0) - 26;
            const h = Math.max(44, Math.min(92, Math.floor((bottom - top - (lines - 1) * GAP) / lines)));
            top += Math.max(0, Math.floor((bottom - top - (lines * h + (lines - 1) * GAP)) / 2));   // the buttons in the middle of what is left
            const bw = cols === 1 ? Math.min(1100, width) : Math.floor((width - (cols - 1) * GAP) / cols);
            const x0 = cols === 1 ? Math.round((W - bw) / 2) : left;
            btns.forEach((b, i) => {
                const x = x0 + (i % cols) * (bw + GAP), by = top + Math.floor(i / cols) * (h + GAP);
                pill(cv, t, x, by, bw, h, b.label, i === 0 && cols === 1);
                cv.target(x, by, bw, h, () => {
                    const c = this.ui.comp(b.name);
                    if (c && c.emit) c.emit('action', {});
                }, 'menu:' + b.name, h / 2);
            });
        }
        G.frame(cv, t, [this.screen.title || ''], 0, []);
        try { d.present(this.screen.name + '_GFX', cv, () => Promise.resolve()); } catch (e) { this.log.warn('menu ' + name + ': ' + e); }
    }
}

function start(ui, log, spec, settings, theme) {
    return (spec.screens || []).filter((s) => s.kind === 'menu').map((s) => new MenuPage(ui, log, spec, settings, theme, s));
}

module.exports = { start, MenuPage };
