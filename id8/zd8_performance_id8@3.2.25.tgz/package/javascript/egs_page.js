'use strict';
/**
 * egs_page.js - the Live page of Transmission Config (apps/zf8hp/main.js 1.5.0) as a page of this app:
 * transmission oil, actual gear and selector, turbine / output shaft speeds, the temperature trace of the
 * current session (ATF / EGS chip 1 / chip 2, picked on the page) and the mechatronics / converter rows.
 *
 * The data comes from the same reader.js / egs.js / catalog.js (verbatim copies): EGS 0x18 is read with
 * 22 <DID> only, the live DIDs every "Live refresh interval" seconds, and only while this page is shown
 * (setActive). Demo: the Display · Demo data setting (Always, or Auto with no car) shows the synthetic
 * records, as Transmission Config's demo does.
 */
const G = require('./kit/gauges');
const { withAlpha } = require('./kit/canvas');
const { fitText } = require('./kit/text-layout');
const { t: translate, getLanguage } = require('./kit/i18n');
const C = require('./catalog');
const E = require('./egs');
const Reader = require('./reader');
const DEMO = require('./demo');

const BLUE = '#81c4ff';
// the Live page's records: oil, gear + selector, turbine / output speeds, engine speed, chips, converter clutch, service window
const LIVE_DIDS = ['6000', 'DA2E', 'DA2A', 'DA34', '6005', '601D', 'DA22', 'DB03'];
const n = (v, digits) => E.finite(v) ? v.toFixed(digits || 0) : '--';

function age(rec) {
    if (!rec || !rec.at) return 'not read';
    const seconds = Math.max(0, Math.round((Date.now() - rec.at) / 1000));
    return (rec.cached ? translate('saved') + ' ' : rec.error ? translate('last good') + ' ' : '')
        + (seconds < 60 ? seconds + translate('s ago') : seconds < 3600 ? Math.floor(seconds / 60) + translate('m ago') : Math.floor(seconds / 3600) + translate('h ago'));
}
function fit(cv, s, max, size) {
    if (getLanguage() === 'zh-CN') return fitText(cv, String(s || ''), size, max);
    s = String(s || '');
    while (s.length > 4 && cv.textWidth(s, size) > max) s = s.slice(0, -4) + '..';
    return s;
}

function create(ctx, car, repaint) {
    const { settings, log } = ctx;
    const reader = new Reader(ctx);
    // 3.1.2: the setting EGS variant picks the one transmission read (reader.js stays the zf8hp copy): Non-hybrid =
    // 0F25D0 (GSZFBCE), Hybrid (no torque converter) = 0F21E0; anything else, or the other one, is not read
    Object.defineProperty(reader, 'supported', {
        get() { return !!reader.sgbd && reader.sgbd === (settings.get('variants') === 'hybrid' ? '0F21E0' : '0F25D0'); },
    });
    // temperatures come from the EGS in °C; shown in the unit picked in Settings
    const fahr = () => settings.get('tempUnit') === 'F';
    const tU = () => (fahr() ? '°F' : '°C');
    const T = (c) => (E.finite(c) ? (fahr() ? c * 9 / 5 + 32 : c) : null);
    const tN = (c, digits) => n(T(c), digits);
    let graphMetric = 0;
    // px below the page where the kit runs the screen with no bar (G.pageBottom), else 0
    let ex = 0;
    const tableRow = (top, count) => Math.floor((508 + ex - top) / Math.max(1, count));
    const demo = () => settings.get('demo') === 'on' || (settings.get('demo') !== 'off' && !!car.data().demo);
    const records = () => demo() ? DEMO.records : reader.records;
    const rec = (d) => records()[d];
    const values = (d) => rec(d) && rec(d).ok ? rec(d).values : [];
    const value = (d, i) => values(d)[i || 0];

    reader.wantFaults = false;
    reader.setWanted(LIVE_DIDS);
    reader.setVisible(false);                 // polled only while this page is shown (setActive)
    reader.init().catch((e) => log.warn('EGS diagnostic link: ' + e));

    /** Where the kit runs the screen: pills of w px from x, the current one filled; a tap or the controller picks one. */
    function choices(cv, t, x, y, labels, w, current, pick, key) {
        labels.forEach((label, i) => { x += G.button(cv, t, x, y, w, 40, label, () => pick(i), { key: key + i, primary: i === current }) + 10; });
        return x;
    }
    /** A panel's label / value rows from y top, rh px each, striped, the text in the middle of the row. */
    function rowList(cv, t, x, w, top, rh, rows) {
        rows.forEach((r, i) => {
            const ry = top + i * rh, ty = ry + rh / 2 + 10;
            if (i % 2) cv.fillRect(x + 10, ry, w - 20, rh, withAlpha('#ffffff', 0.03));
            cv.text(r[0], x + 18, ty, 24, t.dim);
            cv.text(r[1], x + w - 26, ty, 30, t.text, { align: 'right' });
        });
    }
    function freshness(ids) {
        if (demo()) return 'synthetic demo';
        const rs = ids.map(rec), missing = rs.filter((r) => !r || !r.ok).length;
        const old = rs.filter((r) => r && r.at).sort((a, b) => a.at - b.at)[0];
        const errors = rs.filter((r) => r && r.error).length;
        return (missing ? missing + ' pending  /  ' : '') + (errors ? errors + ' read error  /  ' : '') + (old ? age(old) : 'waiting for EGS');
    }
    function card(cv, t, x, w, title, text, unit, sub, color) {
        G.panel(cv, t, x, 44, w, 147, title);
        cv.text(text, x + 18, 145, 55, color || t.text, { font: 'num' });
        if (unit) cv.text(unit, x + w - 18, 142, 23, t.dim, { align: 'right' });
        if (sub) cv.text(sub, x + 18, 177, 17, t.dim);
    }
    function live(cv, t) {
        const oil = value('6000'), gear = C.gearNames[value('DA2E')], selector = C.selectorNames[value('DA2E', 1)];
        // the page's width (1600; wider on iDrive 8): four cards across it, the graph panel takes the extra width
        const W = cv.w || 1600, cw = Math.floor((W - 48 - 3 * 20) / 4), cx = (i) => 24 + i * (cw + 20);
        const RPX = W - 24 - 572, GW = RPX - 20 - 24;
        card(cv, t, cx(0), cw, 'Transmission oil', tN(oil), tU(), age(rec('6000')), BLUE);
        card(cv, t, cx(1), cw, 'Actual gear', gear || '--', selector || '', age(rec('DA2E')));
        card(cv, t, cx(2), cw, 'Turbine / input', n(value('DA2A')), 'rpm', age(rec('DA2A')));
        card(cv, t, cx(3), W - 24 - cx(3), 'Output shaft', n(value('DA2A', 1)), 'rpm', 'Measured at the transmission');
        const names = ['ATF', 'EGS chip 1', 'EGS chip 2'], keys = ['oil', 'chip1', 'chip2'];
        G.panel(cv, t, 24, 210, GW, 302, (cv.own ? 'Temperature' : names[graphMetric]) + ' / current session');
        // where the kit runs the screen the plotted temperature is picked here (a tap or the controller), else the bar's button
        if (cv.own) choices(cv, t, 24 + GW - 400, 222, ['ATF', 'Chip 1', 'Chip 2'], 120, graphMetric, (i) => { graphMetric = i; return repaint(); }, 'graph');
        const hist = demo() ? DEMO.history : reader.history, points = hist.filter((p) => E.finite(p[keys[graphMetric]]));
        const px = 82, py = 284, pw = GW - 96, ph = 172 + ex;
        [0, 0.5, 1].forEach((f) => {
            const y = py + ph * (1 - f);
            cv.line(px, y, px + pw, y, 1, withAlpha(t.text, 0.13));
            cv.text(tN(f * 140), px - 12, y + 6, 18, t.dim, { align: 'right' });
        });
        if (points.length > 1) {
            const start = points[0].t, end = Math.max(start + 1000, points[points.length - 1].t);
            cv.polyline(points.map((p) => [px + (p.t - start) / (end - start) * pw, py + ph * (1 - Math.max(0, Math.min(140, p[keys[graphMetric]])) / 140)]), 3, BLUE);
            cv.text(Math.round((end - start) / 60000) + ' min recorded', px, 488 + ex, 19, t.dim);
        } else cv.text('Waiting for fresh temperature samples', px + pw / 2, py + ph / 2 + 8, 24, t.dim, { align: 'center' });
        G.panel(cv, t, RPX, 210, 572, 302, 'Mechatronics / converter');
        // its records' age (saved values show as such) in its title line
        cv.text(fit(cv, freshness(['6005', '601D', 'DA34', 'DA22', 'DB03']), 220, 19), RPX + 554, 252, 19, t.dim, { align: 'right' });
        const win = values('DB03');
        const rows = [['EGS chip 1', tN(value('6005')) + ' ' + tU()], ['EGS chip 2', tN(value('601D')) + ' ' + tU()],
            ['Engine speed', n(value('DA34')) + ' rpm'], ['Converter clutch', E.TCC[value('DA22')] || '--'],
            ['Reported oil-service window', win.length === 2 ? tN(win[0]) + '..' + tN(win[1]) + ' ' + tU() : '--']];
        rowList(cv, t, RPX, 572, 266, tableRow(266, rows.length), rows);
    }

    return {
        /** The page is shown (and the app's screen is): the EGS is read; hidden: nothing is sent to it. */
        setActive(on) { reader.setVisible(!!on); },
        /** The current tab tapped again: read the page's records again now. */
        refresh() { reader.refresh(); },
        /** The HMI bar's button (standard layout): the next plotted temperature. */
        nextMetric() { graphMetric = (graphMetric + 1) % 3; return repaint(); },
        badges(t) {
            const state = demo() ? 'DEMO' : reader.status();
            return [{ text: 'EXPERIMENTAL', color: t.warn }, { text: state, color: state === 'LIVE' ? BLUE : t.warn }];
        },
        draw(cv, t) {
            ex = G.pageBottom(cv) - G.BOTTOM;
            // another EGS: its message in place of the page (whose controls would still answer under a cover)
            if (!demo() && reader.checked && !reader.supported) {
                cv.text('This EGS variant is not supported by the verified decoder', (cv.w || 1600) / 2, 260 + ex / 2, 32, t.warn, { align: 'center' });
                cv.text('Unsupported EGS variant: ' + reader.sgbd, (cv.w || 1600) / 2, 315 + ex / 2, 25, t.dim, { align: 'center' });
                cv.text('Settings: EGS variant, pick this car\'s transmission type', (cv.w || 1600) / 2, 360 + ex / 2, 22, t.dim, { align: 'center' });
            } else live(cv, t);
        },
    };
}

module.exports = { create, LIVE_DIDS };
