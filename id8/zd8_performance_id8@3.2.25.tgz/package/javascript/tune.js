'use strict';
/**
 * tune.js - the live adjustments the ZD8/BM3 CustomROM offers: Engine Map 1-4 and Burbles.
 *
 * Reduced from apps/live_adjustments/tune.js (Engine Config 0.7.1): the MHD branch (map by 2F echo,
 * Max Cooling) and Active Sound are left out, as asked. Everything ZD8/BM3 is unchanged and goes through
 * the same bm3_protocol.js / bm3_profiles.js (verbatim copies), so the DME sees the same requests in the
 * same order as from Engine Config:
 *
 *   identify   2C 02 F301 24 <marker address> 00 FF, then 22 F301: the CustomROM marker ("BM3_R...#<rom>#")
 *              must name a ROM in bm3_profiles.js, else nothing is written
 *   map        23 14 <mapSwActAddr> 01 reads the active slot; a press writes 3D|3E 14 <addr> 02 <slot> 01
 *              and reads it back (confirmed only when the read-back matches)
 *   burbles    23 14 <burbleActAddr> 01 and 23 14 <timing table> 18 read the state; Apply / Off write both
 *              (3D|3E) and read them back
 *
 * "Tuning software" = Off: nothing at all is sent, not even the identification.
 */
const { Bm3Protocol, positive, addressBytes } = require('./bm3_protocol');
const bm3Profiles = require('./bm3_profiles');

/**
 * ZD8 change (1.0.1): every ROM whose marker reads "BM3_..." uses the 60038006 layout, whatever ROM key it
 * names (also ROMs bm3_profiles.js lists under another layout, and ROMs it does not list at all):
 *   map      3E 14 60 03 80 06 02 <slot> 01, read back 23 14 60 03 80 06 01
 *   burbles  enable 60038099, timing table 60038100 (factor 2)
 * app.json config "bm3Layout" can override it. bm3_protocol.js / bm3_profiles.js stay verbatim copies.
 */
const ZD8_LAYOUT = {
    mapSwActAddr: '60038006',
    burbleActAddr: '60038099',
    timingAddress: '60038100',
    factor: 2,
    wmbaCmd: '3e',
};

/** The ROM key in the marker: the profile it matches, else the first "#<key>" in it, else "BM3". */
function markerKey(text) {
    const known = Object.keys(bm3Profiles).filter((key) => text.includes('#' + key));
    if (known.length === 1) return known[0];
    const m = /#([0-9A-Za-z]{3,})/.exec(text);
    return m ? m[1] : 'BM3';
}

/** The ZD8 layout as a bm3_protocol.js profile. */
function zd8Profile(rom, config) {
    const layout = Object.assign({}, ZD8_LAYOUT, (config && config.bm3Layout) || {});
    return {
        rom,
        mapSwActAddr: layout.mapSwActAddr,
        burbleActAddr: layout.burbleActAddr,
        wmbaCmd: layout.wmbaCmd,
        liveTuneTables: { KF_DZWMIN_SPORT_SOT: { address: layout.timingAddress, factor: layout.factor } },
    };
}

class Zd8Bm3Protocol extends Bm3Protocol {
    /**
     * 1.0.2: by default nothing is sent to identify the ROM (the DME answered the 2C with NRC 33, security
     * access denied): the ZD8 layout is used as is, the first request is the 23 read of the map slot.
     * app.json config "bm3SkipIdentify": false brings back the original 2C + 22 marker check.
     */
    async identify() {
        this.profile = null;
        this.rom = null;
        if (this.config.bm3SkipIdentify !== false) {
            this.rom = 'BM3';
            this.profile = zd8Profile(this.rom, this.config);
            return { rom: this.rom };
        }
        const addr = addressBytes(this.config.bm3MarkerAddress);
        await this.request(0x2C, [0x02, 0xF3, 0x01, 0x24].concat(addr, [0, 0xFF]), [0x02, 0xF3, 0x01]);
        const marker = await this.request(0x22, [0xF3, 0x01], [0xF3, 0x01]);
        positive(marker, 0x22, [0xF3, 0x01]);
        const text = Buffer.from(marker.slice(3)).toString('latin1');
        if (text.indexOf('BM3_') < 0) throw new Error('ZD8/BM3 CustomROM marker absent');
        const rom = markerKey(text);
        this.rom = rom;
        this.profile = zd8Profile(rom, this.config);
        return { rom };
    }
}

/**
 * 1.1.1: what the page says when the DME (or the link to it) fails: "ZD8 DME ..." only, the raw message
 * goes to the log. The English lines have zh-CN entries ("ZD8 DME 拒绝 3E · NRC 33" ...).
 */
function zd8Error(e) {
    const msg = String(e && e.message || e);
    let m = /DME rejected ([0-9A-F]+): NRC ([0-9A-F]+)/i.exec(msg);
    if (m) return 'ZD8 DME rejected ' + m[1].toUpperCase() + ' · NRC ' + m[2].toUpperCase();
    if (/did not answer|timeout|timed out/i.test(msg)) return 'ZD8 DME did not answer';
    if (/unexpected DME response/i.test(msg)) return 'ZD8 DME unexpected reply';
    if (/readback|read-back/i.test(msg)) return 'ZD8 DME read-back mismatch';
    if (/transport unavailable|no diagnostic link/i.test(msg)) return 'ZD8 DME no diagnostic link';
    if (/marker absent|not uniquely matched|profile/i.test(msg)) return 'ZD8 DME not recognised';
    return 'ZD8 DME error';
}

const TUNERS = ['off', 'bm3'];
const FEATURES = {
    off: { map: false, burbles: false, flap: false, asd: false },
    bm3: { map: true, burbles: true, flap: true, asd: true },
};

class TuneControl {
    constructor(ctx) {
        this.ctx = ctx;
        this.log = ctx.log;
        this.link = null;
        this.bm3 = null;
        this._reset();
        this.targetAgg = 1.5;        // burble aggression picked with -/+ (sent on Apply)
    }

    _reset() {
        this.verified = false;       // the ROM marker matched a known profile
        this.map = null;             // 1..4, the map last confirmed by the DME
        this.mapConfirmed = false;   // true = read back from the DME
        this.burbles = null;         // DME state: 'off' | 'custom' | '4.5' | null (unknown)
        this.flap = null;            // exhaust flap last accepted: 'OPEN' | 'CLOSED' | 'OEM' | null (nothing sent yet)
        this.asd = null;             // Active Sound last accepted: true | false | null (the DME does not report it)
        this.busy = false;
        this.note = null;            // the status line under the page
        this.noteFeature = null;     // 2.0: the control the note is about ('map' | 'burbles' | 'flap' | 'asd' | null = start)
        this.noteType = 'dim';       // dim | go | warn
    }

    /** The tune the owner picked in Settings; anything unknown counts as Off. */
    get tuner() {
        const v = this.ctx.settings.get('tuner');
        return TUNERS.indexOf(v) >= 0 ? v : 'off';
    }
    get armed() { return this.tuner !== 'off'; }
    get rom() { return this.verified && this.bm3 ? this.bm3.rom : null; }

    /** Which pages this car gets: the picked tune's. */
    features() { return Object.assign({}, FEATURES[this.tuner]); }

    async start(link) {
        this.link = link;
        if (link && link.diag) this.bm3 = new Zd8Bm3Protocol(link.diag, bm3Profiles, this.ctx.spec.config || {});
        await this.refresh();
    }

    /** The tune changed or the diagnostic link came up: start over. ZD8/BM3 is identified (memory reads
     * only); Off sends nothing. */
    async refresh() {
        const target = this.targetAgg;
        this._reset();
        this.targetAgg = target;
        if (!this.armed) return;
        if (!this.link || !this.link.available) { this.note = 'Waiting for the diagnostic link'; this.noteType = 'warn'; return; }
        try {
            await this._identifyBm3();
            this.map = (await this.bm3.currentMap()) + 1;
            this.mapConfirmed = true;
            await this._readBurbles();
            this.note = 'ZD8 Map ' + this.map + ' · read from the DME';     // 1.2.1: no ROM text, no "active" (zh: 当前故障)
            this.noteType = 'go';
        } catch (e) {
            this.note = zd8Error(e);
            this.noteType = 'warn';
            this.log.info('tune detect (ZD8/BM3): ' + String(e && e.message || e));
        }
        this.log.info('tune: ' + this.tuner + (this.verified ? ' (ROM ' + this.bm3.rom + ')' : ''));
    }

    async _identifyBm3() {
        if (!this.bm3) throw new Error('no diagnostic link');
        if (!this.verified) { await this.bm3.identify(); this.verified = true; }
    }

    async _readBurbles() {
        try {
            const s = await this.bm3.readBurbles();
            this.burbles = !s.enabled ? 'off' : s.aggression === null ? 'custom' : s.aggression.toFixed(1);
            if (s.enabled && s.aggression !== null && s.aggression <= 12) this.targetAgg = s.aggression;
        } catch (e) {
            this.burbles = null;
            this.log.warn('burble readback: ' + String(e && e.message || e));
        }
    }

    /** The one place a command leaves: a tune picked, the feature is that tune's, the link is up
     * and nothing else is running. */
    async _run(feature, label, fn) {
        if (this.busy) return;
        if (!this.armed || !FEATURES[this.tuner][feature]) { this.note = 'Not available for this tune'; this.noteType = 'warn'; return; }
        if (!this.link || !this.link.available || !this.bm3) { this.note = 'Waiting for the diagnostic link'; this.noteType = 'warn'; return; }
        this.busy = true;
        this.noteFeature = feature;
        this.note = 'Sending ' + label + '…'; this.noteType = 'dim';
        try {
            this.note = await fn();
            this.noteType = 'go';
        } catch (e) {
            this.note = zd8Error(e);
            this.noteType = 'warn';
            this.log.warn('tune ' + label + ': ' + String(e && e.message || e));
        } finally {
            this.busy = false;
        }
    }

    /** Map 1..4: one press switches (no confirm step, the user's choice). */
    setMap(n) {
        return this._run('map', 'map ' + n, async () => {
            await this._identifyBm3();
            this.map = (await this.bm3.setMap(n - 1)) + 1;
            this.mapConfirmed = true;
            return 'ZD8 Map ' + this.map + ' · confirmed by the DME';
        });
    }

    /** -/+ only pick the aggression on screen; nothing is sent until Apply. */
    stepAggression(delta) {
        this.targetAgg = Math.max(0, Math.min(12, this.targetAgg + delta));
        this.note = 'Aggression ' + this.targetAgg.toFixed(1) + ' selected · press Apply to send';
        this.noteType = 'dim';
        this.noteFeature = 'burbles';
    }

    /** Apply the picked aggression, or turn the override off (off = true). */
    applyBurbles(off) {
        return this._run('burbles', off ? 'burbles off' : 'burbles ' + this.targetAgg.toFixed(1), async () => {
            await this._identifyBm3();
            const v = await this.bm3.setBurbles(off ? null : this.targetAgg);
            this.burbles = v === null ? 'off' : v.toFixed(1);
            return 'Burbles ' + (v === null ? 'off' : v.toFixed(1)) + ' · confirmed by the DME';
        });
    }

    /**
     * Exhaust flap (1.1.0, from Engine Config's Exhaust Flap page, its ZD8/BM3 adapter): the same
     * bm3_protocol.js setFlap, so the same bytes:
     *   open 2F 60 FD 03 14 FE · close 2F 60 FD 03 23 28 · OEM 2F 60 FD 00 (hands the flap back to the DME)
     * No ROM layout needed, no read-back (the reply does not measure the valve): the state is the last accepted.
     */
    setFlap(mode) {
        const m = { OPEN: 'open', CLOSED: 'close', OEM: 'auto' }[mode];
        if (!m) return Promise.resolve();
        return this._run('flap', 'exhaust flap ' + mode.toLowerCase(), async () => {
            await this.bm3.setFlap(m);
            this.flap = mode;
            return 'Exhaust flap ' + (mode === 'OEM' ? 'OEM' : mode === 'OPEN' ? 'open' : 'closed') + ' · accepted by the DME';
        });
    }

    /** Active Sound Design on / off (Engine Config's Active Sound page): 2E 5F FD 00 (on) | 01 (off), no read-back. */
    setAsd(on) {
        return this._run('asd', 'ASD ' + (on ? 'on' : 'off'), async () => {
            this.asd = await this.bm3.setAsd(!!on);
            return 'Active Sound ' + (this.asd ? 'on' : 'off') + ' · accepted by the DME';
        });
    }

    view() {
        return {
            armed: this.armed,
            tuner: this.tuner,
            features: this.features(),
            verified: this.verified,
            rom: this.rom,
            linked: !!(this.link && this.link.available),
            map: this.map,
            mapConfirmed: this.mapConfirmed,
            readback: true,
            burbles: this.burbles,
            targetAgg: this.targetAgg,
            flap: this.flap,
            asd: this.asd,
            busy: this.busy,
            note: this.note,
            noteType: this.noteType,
            noteFeature: this.noteFeature,
        };
    }
}

module.exports = { TuneControl, TUNERS, FEATURES, ZD8_LAYOUT, Zd8Bm3Protocol, zd8Error };
