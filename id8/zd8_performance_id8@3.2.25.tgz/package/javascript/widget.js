'use strict';
/**
 * widget.js (2.2) - the home-screen widget, as eDrive's and Live Data's (app.json "startWidget": the layout and cell
 * names of BMW's Drive Recorder widget on this firmware; kit/mgu.js Widget does the HMI side, a tap opens the app).
 *
 *   big widget    a 384 x 256 picture: left the engine map big ("MAP 2") with its name, the exhaust flap and the
 *                 burbles; right the engine speed, oil and coolant. The HMI scales it up and crops each edge
 *                 (startWidget.safe), so everything stays inside that margin.
 *   small widget  no picture: the layout's text lines (ASCII only on this firmware, kit/mgu.js widgetText).
 *
 * It sends NOTHING to the car: the tune values are the ones TuneControl already read back / had accepted (at start
 * and on every press), the rest are the car's own signals (kit/car.js).
 */
const { Canvas } = require('./kit/canvas');
const G = require('./kit/gauges');
const { getLanguage } = require('./kit/i18n');
const { MAP_NAMES } = require('./tune_pages');

const zh = () => getLanguage() === 'zh-CN';
const L = (en, cn) => (zh() ? cn : en);

function flapText(f) {
    if (!f) return '–';
    if (f === 'OPEN') return L('OPEN', '已打开');
    if (f === 'CLOSED') return L('CLOSED', '已关闭');
    return L('OEM', '原厂控制');
}
function burbleText(b) {
    if (b === null || b === undefined) return '–';
    if (b === 'off') return L('OFF', '关闭');
    if (b === 'custom') return L('CUSTOM', '自定义');
    return b;
}

function create(ctx, car, tune, gauges) {
    if (!ctx.widget) return null;
    // iDrive 8: another layout (LT_StartmenuWidget_Basic) - its own widget (widget_id8.js)
    if (ctx.spec && ctx.spec.hmi === 'ID8') return require('./widget_id8').create(ctx, car, tune, gauges);
    const { settings } = ctx;
    const wcan = {}, wtext = {}, wlast = {};

    /** The small widget: its text lines; the big one: the layout's text cleared (the picture has the widget). */
    function cells(inst) {
        const on = !inst.big, m = tune.view(), d = car.data();
        const rpm = G.isNum(d.rpm) ? Math.round(d.rpm) + ' rpm' : '-- rpm';
        const c = {
            Title: [on ? 'ZD8 Performance 3.0' : '', 'Text'],
            TextRecordings: [on ? (m.map ? 'Map ' + m.map + '  ' + rpm : rpm) : '', 'Text'],
            TextCam: [on ? 'Flap ' + (m.flap || '-') + '  Burbles ' + (m.burbles || '-') : '', 'Text'],
            TimeElapsed: [on ? 'Oil ' + (G.isNum(d.oil) ? Math.round(d.oil) : '--') + ' C' : '', 'Text'],
            TimeRemaining: [on ? 'Water ' + (G.isNum(d.coolant) ? Math.round(d.coolant) : '--') + ' C' : '', 'Text'],
        };
        const prev = wtext[inst.spawnId] || (wtext[inst.spawnId] = {});
        Object.keys(c).forEach((k) => {
            const v = JSON.stringify(c[k][0]);
            if (prev[k] === v) return;
            prev[k] = v;
            ctx.widget.set(inst.spawnId, k, c[k][0], c[k][1]);
        });
    }

    function render(inst) {
        // one out of sight: again every few seconds only (in case the HMI's "shown" never comes)
        if (!inst.visible && Date.now() - (wlast[inst.spawnId] || 0) < 3000) return null;
        wlast[inst.spawnId] = Date.now();
        cells(inst);
        if (!inst.big) return null;
        const sw = ctx.spec.startWidget || {}, [w, h] = sw.size || [384, 256], [sx, sy] = sw.safe || [0.09, 0.1];
        const key = w + 'x' + h;
        const cv = (wcan[key] = wcan[key] || new Canvas(w, h)).clear([0, 0, 0, 0]);
        const t = ctx.theme(), m = tune.view(), d = car.data();
        const x0 = Math.round(w * sx), x1 = w - x0, y0 = Math.round(h * sy), y1 = h - y0;
        const red = t.crit || '#ef2b2d', ice = t.accent2 || '#81c4ff', go = t.go || '#2fd27a';
        const mid = Math.round(x0 + (x1 - x0) * 0.56);

        // left: the map big, its name; the flap and the burbles
        cv.text('ZD8', x0, y0 + 14, 13, red, { font: 'bold', spacing: 1.5 });
        if (d.demo) cv.text(L('DEMO', '演示'), x0 + 40, y0 + 14, 13, t.warn || '#d29922', { font: 'bold', spacing: 1 });
        cv.text(m.map ? 'MAP ' + m.map : 'MAP –', x0, y0 + 64, 44, m.map ? t.text : t.dim, { font: 'bold', spacing: 1 });
        cv.text(m.map ? MAP_NAMES[m.map - 1] : (m.armed ? 'Pick a map' : L('Tuning off', '调校已关闭')), x0, y0 + 92, 18,
            m.map ? (m.mapConfirmed ? go : t.dim) : t.dim, { font: 'label' });
        const row = (y, label, value, col) => {
            cv.text(label, x0, y, 15, t.dim, { font: 'label' });
            cv.text(value, x0 + 74, y, 18, col, { font: 'bold' });
        };
        const fcol = m.flap === 'OPEN' ? ice : m.flap === 'CLOSED' ? red : m.flap ? t.text : t.dim;
        row(y1 - 40, L('Flap', '阀门'), flapText(m.flap), fcol);
        row(y1 - 8, L('Burbles', '回火'), burbleText(m.burbles), m.burbles && m.burbles !== 'off' ? t.text : t.dim);

        // right: engine speed, oil, coolant
        cv.fillRect(mid - 14, y0 + 6, 1, y1 - y0 - 12, G.withAlpha('#ffffff', 0.15));
        const rpm = G.isNum(d.rpm) ? String(Math.round(d.rpm / 10) * 10) : '----';
        cv.text(rpm, x1, y0 + 56, 36, G.isNum(d.rpm) ? t.text : t.dim, { font: 'num', align: 'right' });
        cv.text('RPM', x1, y0 + 76, 13, t.dim, { font: 'bold', spacing: 1.5, align: 'right' });
        const temp = (y, label, v, warmAt) => {
            const col = !G.isNum(v) ? t.dim : v < warmAt ? (t.cold || ice) : v > 130 ? red : t.text;
            cv.text(label, mid, y, 15, t.dim, { font: 'label' });
            cv.text(G.isNum(v) ? Math.round(v) + '°' : '--', x1, y, 22, col, { font: 'bold', align: 'right' });
        };
        temp(y1 - 40, L('Oil', '油温'), d.oil, settings.get('warmOil') || 80);
        temp(y1 - 8, L('Water', '水温'), d.coolant, 70);
        return cv;
    }

    ctx.widget.loop(() => settings.get('widgetFps') || 4, render);
    ctx.widget.onChange((why) => { if (why === 'resized' || why === 'placed') Object.keys(wtext).forEach((k) => delete wtext[k]); });
    return { render };
}

module.exports = { create };
