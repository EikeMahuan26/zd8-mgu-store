'use strict';
/**
 * widget_id8.js (3.2.18) - the iDrive 8 home-screen widget.
 *
 * iDrive 8's MainApp gives a custom widget one layout, LT_StartmenuWidget_Basic (Hmi8's HmiGen_GenerationRules.xml,
 * rule "startWidget"): a picture (Graphic), Title, TitleIcon(Visible), Loading and one InfoText line. iDrive 7's
 * Drive Recorder cells (TextRecordings, TextCam, ...) do not exist there. So the widget is one drawn picture:
 *
 *   top      the engine map (ZD8, "MAP 2" big, its name)
 *   gauges   the Gauges page's right column, the same drawing (kit/gauges): Speed + gear, Power and Torque segment
 *            bars with the 3 s peak hold and the red zone; and its four small bars Oil, Coolant, Intake air, Battery
 *
 * Square widget: the map, speed / power / torque, the four small bars in a row. Wide: the map and the four bars
 * stacked on the left, speed / power / torque on the right (as the Gauges page).
 * The canvas is drawn at the Gauges page's own pixel scale (800 x 800 / 1600 x 800, app.json startWidget.id8.sizes);
 * Hmi8 scales it into the Graphic slot. Setting widgetCal draws a calibration frame instead.
 *
 * Values as on the Gauges page: speed, rpm, torque, oil, coolant, gear from the car's own signals; power = torque x
 * rpm; battery = the head unit's supply voltage; intake air = OBD PID 0F to the DME, read only while a widget shows
 * and setting widgetObd is on (the Gauges page's read-only service 01 rotation, never during a tune command).
 * Title stays the widget's name (static preview); InfoText gets a one-line ASCII summary.
 */
const { Canvas } = require('./kit/canvas');
const G = require('./kit/gauges');
const { getLanguage } = require('./kit/i18n');
const { MAP_NAMES } = require('./tune_pages');
const { softLayer } = require('./kit/record');

/**
 * The widget's picture: a plain canvas (it goes to the HMI as a PNG), which also takes kit/gauges' cached layers (the
 * panels): a layer is played into its own canvas once (record.js softLayer) and copied in.
 */
function makeCanvas(w, h) {
    const cv = new Canvas(w, h);
    cv.blit = function (src, x, y) { return Canvas.prototype.blit.call(this, src && src.layerId !== undefined ? softLayer(src) : src, x, y); };
    return cv;
}

const zh = () => getLanguage() === 'zh-CN';
const L = (en, cn) => (zh() ? cn : en);
// Hmi8 sends no widget size when a widget is placed (only on a resize): the big square layout unless app.json says otherwise
const DEFAULT_SIZES = { default: [800, 960] };
// the tall card's content band (fractions of the height): under the card's Title + InfoText, over the climate bar
// (measured on the car: card 544 x 960 on screen, Title to ~17 %, the climate bar from 87.5 %)
const TALL_AREA = [0.175, 0.872];
const PEAK_MS = 3000;
const PAD = 24;

const rnd = (v, d) => (G.isNum(v) ? +v.toFixed(d || 0) : undefined);
function gearShown(d) {
    const st = d.stage, g = d.gear;
    if (st === 'P' || st === 'R' || st === 'N') return st;
    if (G.isNum(g) && g > 0) return (st === 'D' || st === undefined ? 'D' : '') + g;
    if (g === -1) return 'R';
    return st || '-';
}

/** A text that fits maxW: the size shrinks down to 55 %. */
function fitText(cv, s, x, y, size, maxW, c, opts) {
    let sz = size;
    while (sz > size * 0.55 && cv.textWidth(s, sz, opts) > maxW) sz -= 1;
    cv.text(s, x, y, sz, c, opts);
}

/** The engine map: ZD8, MAP n big, its name; in x..x+w from y, h high. */
function drawMap(cv, t, m, d, x, y, w, h) {
    const red = t.crit || '#ef2b2d', go = t.go || '#2fd27a';
    const small = Math.round(h * 0.2), big = Math.round(h * 0.56);
    cv.text('ZD8', x, y + small, small, red, { font: 'bold', spacing: 1.5 });
    if (d.demo) cv.text(L('DEMO', '演示'), x + Math.round(small * 3.2), y + small, small, t.warn || '#d29922', { font: 'bold' });
    const mapTxt = m.map ? 'MAP ' + m.map : 'MAP –';
    const by = y + small + Math.round(h * 0.12) + big;
    cv.text(mapTxt, x, by, big, m.map ? t.text : t.dim, { font: 'bold', spacing: 1 });
    const mw = cv.textWidth(mapTxt, big, { font: 'bold', spacing: 1 }) + Math.round(big * 0.35);
    const name = m.map ? MAP_NAMES[m.map - 1] : (m.armed ? L('Pick a map', '请选择程序') : L('Tuning off', '调校已关闭'));
    fitText(cv, String(name || ''), x + mw, by, Math.round(big * 0.5), w - mw, m.map ? (m.mapConfirmed ? go : t.dim) : t.dim, { font: 'label' });
}

/** The Gauges page's right column: Speed + gear, Power, Torque (x, y, w, h). */
function drawRight(cv, t, v, s, x, y, w, h, o) {
    o = o || {};
    const sc = (every) => ({ size: 18, every, labelY: 32, tick: 6 });
    const red = (k) => +(s(k) * 0.9).toFixed(2);
    const spH = o.speedH || 130, gap = o.gap || 10;
    const segH = o.segH || Math.min(220, Math.floor((h - spH - 2 * gap) / 2));
    const y0 = y + Math.floor((h - (spH + 2 * gap + 2 * segH)) / 2);
    const big = spH >= 130 ? 60 : 52;
    G.panel(cv, t, x, y0, w, spH, L('Speed', '车速'));
    G.readout(cv, t, x + 24, y0 + (spH >= 130 ? 58 : 50), { value: v.speed, unit: 'km/h', decimals: 0, size: big });
    cv.text(v.gear, x + w - 24, y0 + spH - 18, Math.round(big * 1.2), t.dim, { align: 'right', font: 'bold' });
    G.segBar(cv, t, x, y0 + spH + gap, w, segH, { label: L('Power', '功率'), unit: 'hp', min: 0, max: s('gPowerMax'), value: v.hp,
        decimals: 0, limit: red('gPowerMax'), step: s('gPowerMax') > 500 ? 50 : 25, scale: sc(100), ramp: 'hot', peak: v.hpPeak });
    G.segBar(cv, t, x, y0 + spH + 2 * gap + segH, w, segH, { label: L('Torque', '扭矩'), unit: 'Nm', min: 0, max: s('gTorqueMax'), value: v.tq,
        decimals: 0, limit: red('gTorqueMax'), step: 50, scale: sc(100), ramp: 'hot', peak: v.tqPeak });
}

/** The four small bars: Oil, Coolant, Intake air, Battery. cols x rows in (x, y, w, h). */
function drawSmall(cv, t, v, s, x, y, w, h, cols, step) {
    // four in a row on the big card: short English labels (the value shares the bar's width)
    const short = (w - 24 * (cols - 1)) / cols < 250;
    const list = [
        [L('Oil', '机油'), '°C', 40, s('gOilMax'), v.oil, 0],
        [L(short ? 'Water' : 'Coolant', '冷却液'), '°C', 40, s('gCoolantMax'), v.coolant, 0],
        [L(short ? 'IAT' : 'Intake air', '进气'), '°C', -20, s('gIntakeMax'), v.intake, 0],
        [L(short ? 'Batt' : 'Battery', '电池'), 'V', 10, 16, v.battery, 1],
    ];
    const rows = Math.ceil(list.length / cols), gap = 24;
    // rows a fixed step apart (at most 150 px), the block centred in h
    const bw = (w - gap * (cols - 1)) / cols, rowH = rows > 1 ? Math.min(step || 150, (h - 96) / (rows - 1)) : 0;
    const top = y + (h - ((rows - 1) * rowH + 96)) / 2;
    list.forEach(([label, unit, min, max, val, dec], i) => {
        const bx = x + (i % cols) * (bw + gap), by = top + Math.floor(i / cols) * rowH;
        G.bar(cv, t, Math.round(bx), Math.round(by), Math.round(bw), 96, { label, unit, min, max: max || min + 100, value: val, decimals: dec, ramp: 'hot',
            step: bw < 250 ? ((max || min + 100) - min) / 2 : undefined });   // narrow: 3 scale labels, no overlap
    });
}

/**
 * Draw the widget into cv (its whole size). v = { speed, gear, hp, hpPeak, tq, tqPeak, oil, coolant, intake, battery }
 * (values() below); s = setting getter. Exported for the offline preview.
 */
function draw(cv, t, m, d, v, s, area) {
    const w = cv.w, h = cv.h;
    if (h / w >= 1.2) {
        // tall (iDrive 8's widget card, ~544 x 960 on screen: the picture is its background, scaled to the card's height):
        // the card's own Title / InfoText cover the top, the climate bar the bottom - the content goes between (area)
        const [ft, fb] = area || TALL_AREA;
        const top = Math.round(h * ft), bot = Math.round(h * fb), x = Math.round(w * 0.037), cw = w - 2 * x;
        // the band's height shared out: map, speed, power, torque, the four small bars (2 x 2); a taller band (a wider
        // canvas, same shape) gets taller bars, up to 240 px each
        const avail = bot - top, roomy = avail >= 900;
        const mapH = roomy ? 84 : 64, spH = roomy ? 130 : 112, gap = roomy ? 10 : 6, step = roomy ? 124 : 104;
        // a short band (the big 800 x 960 card: ~670 px between its Title and the climate bar): the four bars in one row
        const oneRow = avail < 760;
        const smallH = oneRow ? 96 : step + 96;
        const segH = Math.max(166, Math.min(240, Math.floor((avail - mapH - 8 - spH - 2 * gap - smallH - 8) / 2)));
        const used = mapH + 8 + spH + 2 * gap + 2 * segH + 8 + smallH, y0 = top + Math.max(0, Math.floor((avail - used) / 2));
        drawMap(cv, t, m, d, x, y0, cw, mapH);
        drawRight(cv, t, v, s, x, y0 + mapH + 8, cw, spH + 2 * gap + 2 * segH, { speedH: spH, segH, gap });
        drawSmall(cv, t, v, s, x, y0 + used - smallH, cw, smallH, oneRow ? 4 : 2, step);
        return cv;
    }
    if (w / h >= 1.5) {
        // wide: left the map + the four bars stacked, right speed / power / torque (as the Gauges page)
        const LW = Math.round((w - 3 * PAD) * 0.5), RX = PAD + LW + PAD, RW = w - PAD - RX;
        const mapH = Math.round((h - 2 * PAD) * 0.24);
        drawMap(cv, t, m, d, PAD, PAD, LW, mapH);
        drawSmall(cv, t, v, s, PAD, PAD + mapH + 30, LW, h - 2 * PAD - mapH - 30, 2);
        drawRight(cv, t, v, s, RX, PAD, RW, h - 2 * PAD);
    } else {
        // square: the map on top, speed / power / torque, the four bars in a row at the bottom
        const mapH = Math.round(h * 0.15);
        drawMap(cv, t, m, d, PAD, PAD, w - 2 * PAD, mapH);
        const bottom = 96 + 4;
        drawRight(cv, t, v, s, PAD, PAD + mapH + 14, w - 2 * PAD, h - 2 * PAD - mapH - 14 - bottom - 16);
        drawSmall(cv, t, v, s, PAD, h - PAD - 96, w - 2 * PAD, 96, 4);
    }
    return cv;
}

/** Calibration picture: the edges, 5 % and 10 % insets, the size and the centre. */
function drawCalibration(cv, t) {
    const w = cv.w, h = cv.h;
    cv.clear([0, 0, 0, 0]);
    const frame = (k, c) => {
        const ix = Math.round(w * k), iy = Math.round(h * k), b = Math.max(3, Math.round(Math.min(w, h) / 160));
        cv.fillRect(ix, iy, w - 2 * ix, b, c); cv.fillRect(ix, h - iy - b, w - 2 * ix, b, c);
        cv.fillRect(ix, iy, b, h - 2 * iy, c); cv.fillRect(w - ix - b, iy, b, h - 2 * iy, c);
    };
    frame(0, '#ef2b2d'); frame(0.05, '#d29922'); frame(0.1, '#2fd27a');
    cv.fillRect(Math.round(w / 2) - 1, 0, 2, h, G.withAlpha('#ffffff', 0.4));
    cv.fillRect(0, Math.round(h / 2) - 1, w, 2, G.withAlpha('#ffffff', 0.4));
    const sz = Math.round(Math.min(w, h) * 0.09);
    cv.text(w + ' x ' + h, Math.round(w / 2), Math.round(h / 2) - sz, sz, t.text || '#ffffff', { font: 'bold', align: 'center' });
    cv.text('red = edge   yellow = 5%   green = 10%', Math.round(w / 2), Math.round(h / 2) + Math.round(sz * 1.6), Math.round(sz * 0.6), t.dim || '#aaaaaa', { font: 'label', align: 'center' });
    return cv;
}

function create(ctx, car, tune, gauges) {
    if (!ctx.widget) return null;
    const { settings } = ctx;
    const s = (k) => settings.get(k);
    const sw = ctx.spec.startWidget || {};
    const sizes = Object.assign({}, DEFAULT_SIZES, sw.sizes || {});
    const wcan = {}, wtext = {}, wlast = {};
    const peaks = {};
    function peak(k, val) {
        if (!G.isNum(val)) return undefined;
        const p = peaks[k], now = Date.now();
        if (!p || val >= p.v || now - p.at > PEAK_MS) peaks[k] = { v: val, at: now };
        return peaks[k].v;
    }
    function values(d) {
        const hp = G.isNum(d.torque) && G.isNum(d.rpm) ? rnd(d.torque * d.rpm / 9549.3 * 1.341) : undefined, tq = rnd(d.torque);
        return {
            speed: rnd(d.speed), gear: gearShown(d), hp, hpPeak: peak('hp', hp), tq, tqPeak: peak('nm', tq),
            oil: rnd(d.oil), coolant: rnd(d.coolant),
            intake: gauges && gauges.intake ? rnd(gauges.intake()) : undefined,
            battery: gauges && gauges.battery ? rnd(gauges.battery(), 1) : undefined,
        };
    }

    function cells(inst, m, v) {
        const parts = [m.map ? 'MAP ' + m.map : 'MAP -', G.isNum(v.hp) ? v.hp + ' hp' : null, G.isNum(v.tq) ? v.tq + ' Nm' : null].filter(Boolean);
        const c = { InfoText: [sw.infoText === false ? '' : parts.join('  '), 'Text'], Loading: [false, 'Bool'], TitleIconVisible: [false, 'Bool'] };
        const prev = wtext[inst.spawnId] || (wtext[inst.spawnId] = {});
        Object.keys(c).forEach((k) => {
            const j = JSON.stringify(c[k][0]);
            if (prev[k] === j) return;
            prev[k] = j;
            ctx.widget.set(inst.spawnId, k, c[k][0], c[k][1]);
        });
    }

    function render(inst) {
        if (!inst.visible && Date.now() - (wlast[inst.spawnId] || 0) < 3000) return null;
        wlast[inst.spawnId] = Date.now();
        const m = tune.view(), d = car.data(), v = values(d);
        cells(inst, m, v);
        const [w, h] = sizes[String(inst.size)] || sizes.default;
        const key = w + 'x' + h;
        const cv = (wcan[key] = wcan[key] || makeCanvas(w, h)).clear([0, 0, 0, 0]);
        if (s('widgetCal')) return drawCalibration(cv, ctx.theme());
        return draw(cv, ctx.theme(), m, d, v, s, sw.area);
    }

    // intake air: OBD only while a widget shows (and setting widgetObd allows it)
    const obdFollow = () => { if (gauges && gauges.setWidgetActive) gauges.setWidgetActive(s('widgetObd') !== false && ctx.widget.active()); };
    ctx.widget.loop(() => s('widgetFps') || 4, render);
    ctx.widget.onChange((why) => { if (why === 'resized' || why === 'placed') Object.keys(wtext).forEach((k) => delete wtext[k]); obdFollow(); });
    setInterval(obdFollow, 2000);
    return { render };
}

module.exports = { create, draw, drawCalibration, makeCanvas, DEFAULT_SIZES, gearShown };
