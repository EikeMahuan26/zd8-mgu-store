'use strict';
/**
 * tune_pages.js - the two ZD8/BM3 pages, drawn as in Engine Config (apps/live_adjustments/ui.js: drawMap,
 * drawBurbles, noteLine, buttonRow), a pure draw(cv, G, t, page, m, act):
 *   'map'      the active map big, four slot bars, Map 1-4 buttons (one press switches)
 *   'burbles'  the picked aggression big, the DME's state, - / + / Apply / Off
 *   'flap'     Engine Config's Exhaust Flap page: twin tailpipes with the butterfly valves, Open / Close / OEM
 *   'asd'      Engine Config's Active Sound page: ON / OFF big, On / Off
 * m = TuneControl.view(), act = { map(n) -> fn, aggDown, aggUp, burblesApply, burblesOff, flap(mode) -> fn, asd(on) -> fn }.
 * With "Tuning software" Off the page says so and has no buttons (nothing is sent).
 */
// the page's width: 1600, wider on iDrive 8 (set from the canvas by every drawing entry point below)
let W = 1600;
const useWidth = (cv) => { W = (cv && cv.w) || 1600; PE.mapW = Math.round((W - 48 - PE.gap) * 930 / 1526); };
const RED = (t) => t.crit || '#ef2b2d';
// the four map buttons (slot 1..4), named by the owner (1.1.0)
// the language, read lazily: the tests load this file without the kit next to it
const getLanguage = () => { try { return require('./kit/i18n').getLanguage(); } catch (e) { return ''; } };
const MAP_NAMES = ['Base Power', 'Aggressive Power', 'Race Power', 'Stock Power'];

/** The status line just above the buttons: what the DME said, or why nothing was sent. */
function noteLine(cv, G, t, m, bottom) {
    if (!m.note) return;
    const c = m.noteType === 'warn' ? (t.warn || '#d29922') : m.noteType === 'go' ? (t.go || '#2fd27a') : t.dim;
    cv.text(m.note, W / 2, bottom - 80, 18, c, { align: 'center', font: 'label' });
}

/** A row of equal buttons centred across the page bottom; spec = [label, run, selected]. */
function buttonRow(cv, G, t, specs, bottom, bw, busy, keyPrefix) {
    const bh = 56, gap = 26, by = bottom - 56;
    let bx = (W - (specs.length * bw + (specs.length - 1) * gap)) / 2;
    specs.forEach(([label, run, on], i) => {
        const opts = { key: keyPrefix + i, busy: !!busy };
        if (on) Object.assign(opts, { color: RED(t), primary: true });
        G.button(cv, t, bx, by, bw, bh, label, run || (() => {}), opts);
        bx += bw + gap;
    });
}

/** Engine Map: the active map big, four slot bars, MAP 1-4 (one press switches). */
function drawMap(cv, G, t, m, act, bottom) {
    useWidth(cv);
    const cy = G.TOP + (bottom - G.TOP - 96) / 2 - 20;
    cv.text(m.map ? 'MAP ' + m.map : 'MAP –', W / 2, cy + 30, 112, m.map ? t.text : t.dim,
        { align: 'center', font: 'bold', spacing: 4 });
    cv.text(m.map ? (m.mapConfirmed ? 'Active map · read from the DME' : 'Selected map · accepted by the DME')
        : 'Pick a map', W / 2, cy + 74, 18, t.dim, { align: 'center', font: 'label', spacing: 1 });
    const pw = 120, pg = 18, px0 = (W - (4 * pw + 3 * pg)) / 2;
    for (let i = 0; i < 4; i++) {
        cv.roundRect(px0 + i * (pw + pg), cy + 96, pw, 8, 4, m.map === i + 1 ? RED(t) : G.withAlpha('#ffffff', 0.12));
    }
    noteLine(cv, G, t, m, bottom);
    buttonRow(cv, G, t, [1, 2, 3, 4].map((n) => [MAP_NAMES[n - 1], act.map && act.map(n), m.map === n]),
        bottom, 230, m.busy, 'la_map');
    return cv;
}

/** Burbles: the DME's state and the picked aggression; -/+ pick, Apply sends, Off disables. */
function drawBurbles(cv, G, t, m, act, bottom) {
    useWidth(cv);
    const cy = G.TOP + (bottom - G.TOP - 96) / 2 - 20;
    const agg = typeof m.targetAgg === 'number' ? m.targetAgg : 0;
    cv.text(agg.toFixed(1), W / 2, cy + 30, 112, t.text, { align: 'center', font: 'bold', spacing: 4 });
    cv.text('Aggression 0.0 – 12.0', W / 2, cy + 74, 18, t.dim, { align: 'center', font: 'label', spacing: 1 });
    const state = m.burbles === null || m.burbles === undefined ? 'unknown'
        : m.burbles === 'off' ? 'off' : m.burbles === 'custom' ? 'custom value' : m.burbles;
    cv.text('Now on the DME: ' + state, W / 2, cy + 104, 18, t.dim, { align: 'center', font: 'label' });
    noteLine(cv, G, t, m, bottom);
    buttonRow(cv, G, t, [['–', act.aggDown, false], ['+', act.aggUp, false],
        ['Apply', act.burblesApply, false], ['Off', act.burblesOff, m.burbles === 'off']],
        bottom, 200, m.busy, 'la_burb');
    return cv;
}

/* ---------- Exhaust Flap (Engine Config ui.js: drawExhaust / drawTip / drawButtons) ---------- */

let flapAngle = 0.18;     // eased valve angle per frame (0 = shut, 1 = open, 0.18 = the DME in control)

function flapTarget(s) {
    if (s === 'OPEN') return 1;
    if (s === 'CLOSED') return 0;
    if (s === 'OEM') return 0.18;
    return 0.5;
}

/** One tailpipe tip seen end-on: chromed bezel, dark bore, the butterfly valve (open 0 = shut, 1 = open). */
function drawTip(cv, G, t, cx, cy, r, open, accent) {
    const wa = G.withAlpha;
    cv.circle(cx, cy + 4, r + 6, wa('#000000', 0.32));
    cv.circle(cx, cy, r + 2, '#0b0e12');
    cv.circle(cx, cy, r, '#9aa1ac');
    cv.circle(cx, cy, r * 0.93, '#565d68');
    cv.circle(cx, cy, r * 0.87, '#cdd2da');
    cv.circle(cx, cy, r * 0.79, '#272c34');
    cv.circle(cx, cy, r * 0.71, '#9ea5af');
    const rb = r * 0.65;
    cv.circle(cx, cy, rb, '#0a0c10');
    cv.circle(cx, cy - rb * 0.1, rb * 0.9, '#050608');
    if (open > 0.4) {
        const g = (open - 0.4) / 0.6;
        cv.circle(cx, cy, rb * 0.72, wa(accent, 0.13 * g));
        cv.circle(cx, cy, rb * 0.4, wa(accent, 0.20 * g));
    }
    const ws = Math.max(0.10, Math.cos(open * Math.PI / 2 * 0.95));
    const pw = 2 * rb * ws;
    cv.roundRect(cx - pw / 2, cy - rb, pw, 2 * rb, Math.min(pw / 2, rb), '#c7cdd5');
    if (pw > 12) cv.roundRect(cx - pw * 0.28, cy - rb * 0.92, pw * 0.3, rb * 1.84, Math.min(pw * 0.15, rb), wa('#ffffff', 0.28));
    cv.line(cx, cy - rb, cx, cy + rb, 2, wa('#20242b', 0.8));
    cv.circle(cx, cy, 5.5, '#1a1e24'); cv.circle(cx, cy, 2.5, '#434a53');
    cv.circle(cx - r * 0.4, cy - r * 0.48, r * 0.1, wa('#ffffff', 0.5));
}

/** Exhaust Flap: the twin tips easing to the state, the state word, Open / Close / OEM (the picked one red). */
function drawFlap(cv, G, t, m, act, bottom) {
    useWidth(cv);
    const tgt = flapTarget(m.flap);
    flapAngle += (tgt - flapAngle) * 0.25;
    if (Math.abs(tgt - flapAngle) < 0.003) flapAngle = tgt;
    const x = W / 2 - 310, y = G.TOP + 18, w = 620, h = 250 + bottom - G.BOTTOM;
    const accent = m.flap === 'OPEN' ? (t.accent2 || '#81c4ff') : RED(t);
    const cx = x + w * 0.5, cy = y + h * 0.5 - 20;
    const r = Math.min(h * 0.36, w * 0.19);
    const ox = r * 0.8, oy = r * 0.32;
    drawTip(cv, G, t, cx - ox, cy + oy, r, flapAngle, accent);
    drawTip(cv, G, t, cx + ox, cy - oy, r, flapAngle, accent);
    const word = m.flap || '–';
    const col = m.flap === 'OPEN' ? (t.accent2 || '#81c4ff') : m.flap === 'CLOSED' ? RED(t) : m.flap ? t.text : t.dim;
    cv.text(word, W / 2, bottom - 112, 44, col, { align: 'center', font: 'bold', spacing: 2 });
    noteLine(cv, G, t, m, bottom);
    const f = act.flap || (() => null);
    buttonRow(cv, G, t, [['Open', f('OPEN'), m.flap === 'OPEN'], ['Close', f('CLOSED'), m.flap === 'CLOSED'],
        ['OEM', f('OEM'), m.flap === 'OEM']], bottom, 236, m.busy, 'la_flap');
    return cv;
}

/** Active Sound (ASD): the interior engine sound on / off; the DME does not report its state. */
function drawAsd(cv, G, t, m, act, bottom) {
    useWidth(cv);
    const cy = G.TOP + (bottom - G.TOP - 96) / 2 - 20;
    const word = m.asd === true ? 'ON' : m.asd === false ? 'OFF' : '–';
    cv.text(word, W / 2, cy + 30, 112, m.asd == null ? t.dim : t.text, { align: 'center', font: 'bold', spacing: 4 });
    cv.text('Active Sound Design · the last setting the DME accepted', W / 2, cy + 74, 18, t.dim,
        { align: 'center', font: 'label', spacing: 1 });
    noteLine(cv, G, t, m, bottom);
    const a = act.asd || (() => null);
    buttonRow(cv, G, t, [['On', a(true), m.asd === true], ['Off', a(false), m.asd === false]], bottom, 236, m.busy, 'la_asd');
    return cv;
}

/* ---------- 2.0: Performance & Exhaust (the left two cards of IterioDev's Live Adjustments, ID8) ----------
 * Its 2880 x 960 design: the ENGINE MAP card (58..1308) and the EXHAUST FLAP card (1348..2108), y 236..820, here
 * scaled into the page's content area. Engine map: label, the map big, its state line, four map buttons (the picked
 * one red). Exhaust flap: label with the state on the right, the twin tailpipes side by side, its state line,
 * Open / Close / OEM (the picked one filled). The same TuneControl calls as the Power Map and Exhaust Flap pages. */

const PE = { x: 24, gap: 26, mapW: 930 };

/** A card: the house panel, rounded, its label top left (the ID8 card has no title bar). */
function card(cv, G, t, x, y, w, h, label) {
    cv.roundRect(x, y, w, h, 16, G.withAlpha('#ffffff', 0.05));
    cv.strokeRoundRect(x, y, w, h, 16, 1.5, G.withAlpha('#ffffff', 0.10));
    cv.text(label, x + 32, y + 46, 20, t.dim, { font: 'bold', spacing: 2 });
}

/** A row of tall buttons inside a card (x0..x0+w), the selected one filled. specs = [label, run, on, color]. */
function cardButtons(cv, G, t, x0, w, y, h, specs, busy, keyPrefix) {
    const gap = 16, bw = (w - gap * (specs.length - 1)) / specs.length;
    specs.forEach(([label, run, on, color], i) => {
        const opts = { key: keyPrefix + i, busy: !!busy };
        if (on) Object.assign(opts, { color: color || RED(t), primary: true });
        G.button(cv, t, x0 + i * (bw + gap), y, bw, h, label, run || (() => {}), opts);
    });
}

function drawPerfExhaust(cv, G, t, m, act, bottom) {
    useWidth(cv);
    const y = G.TOP + 10, h = bottom - y;
    const mapW = PE.mapW, flapX = PE.x + mapW + PE.gap, flapW = W - 24 - flapX;
    const bh = 76, by = y + h - 28 - bh;                  // the buttons along each card's bottom
    const go = t.go || '#2fd27a', warn = t.warn || '#d29922', ice = t.accent2 || '#81c4ff';
    const noteCol = (m.noteType === 'warn' ? warn : m.noteType === 'go' ? go : t.dim);

    // ---- ENGINE MAP
    card(cv, G, t, PE.x, y, mapW, h, 'ENGINE MAP');
    const mx = PE.x + 32;
    // the map's own name as the big readout (基础动力 / 激进动力 / 赛用动力 / 原厂动力); the English names are longer
    const bigSize = getLanguage() === 'zh-CN' ? 120 : 76;
    cv.text(m.map ? MAP_NAMES[m.map - 1] : 'MAP –', mx, y + 170, bigSize, m.map ? t.text : t.dim, { font: 'bold', spacing: 4 });
    const mapNote = m.note && (m.noteFeature === 'map' || m.noteFeature === null) ? [m.note, noteCol]
        : m.map ? [m.mapConfirmed ? 'Active map · read from the DME' : 'Selected map · accepted by the DME', go] : ['Pick a map', t.dim];
    cv.text(mapNote[0], mx, y + 218, 21, mapNote[1], { font: 'label' });
    cardButtons(cv, G, t, mx, mapW - 64, by, bh,
        [1, 2, 3, 4].map((n) => [MAP_NAMES[n - 1], act.map && act.map(n), m.map === n, RED(t)]), m.busy, 'pe_map');

    // ---- EXHAUST FLAP
    card(cv, G, t, flapX, y, flapW, h, 'EXHAUST FLAP');
    const fcol = m.flap === 'OPEN' ? ice : m.flap === 'CLOSED' ? RED(t) : m.flap ? t.text : t.dim;
    cv.text(m.flap || '–', flapX + flapW - 32, y + 46, 24, fcol, { align: 'right', font: 'bold', spacing: 1 });
    // the twin tailpipes side by side, easing to the state
    const tgt = flapTarget(m.flap);
    flapAngle += (tgt - flapAngle) * 0.25;
    if (Math.abs(tgt - flapAngle) < 0.003) flapAngle = tgt;
    const r = Math.min(70, (by - (y + 70) - 70) / 2), cy = y + 70 + r + 14, cx = flapX + flapW / 2;
    const accent = m.flap === 'OPEN' ? ice : RED(t);
    drawTip(cv, G, t, cx - r - 12, cy, r, flapAngle, accent);
    drawTip(cv, G, t, cx + r + 12, cy, r, flapAngle, accent);
    const flapNote = m.note && m.noteFeature === 'flap' ? [m.note, noteCol]
        : m.flap ? ['Last setting accepted by the DME', go] : ['Not sent yet', t.dim];
    cv.text(flapNote[0], flapX + 32, by - 22, 19, flapNote[1], { font: 'label' });
    const f = act.flap || (() => null);
    cardButtons(cv, G, t, flapX + 32, flapW - 64, by, bh, [['Open valve', f('OPEN'), m.flap === 'OPEN', ice],
        ['Close', f('CLOSED'), m.flap === 'CLOSED', RED(t)], ['OEM', f('OEM'), m.flap === 'OEM', t.sel || t.accent]], m.busy, 'pe_flap');
    return cv;
}

/* ---------- 2.1: Sound (Burbles + Active Sound on one page, the same two-card layout as Performance & Exhaust) ----
 * Left card BURBLES: the picked aggression big, the range, the DME's state, - / + / Apply / Off (Off red when the
 * DME has them off). Right card ACTIVE SOUND: its state top right, a speaker and ON / OFF big, On / Off. The same
 * TuneControl calls as the Burbles and Active Sound pages. */

/** A speaker seen from the side: the box, the cone, sound arcs when on. */
function drawSpeaker(cv, G, t, x, y, s, on, col) {
    const c = on ? col : G.withAlpha('#ffffff', 0.35);
    cv.roundRect(x, y + s * 0.32, s * 0.26, s * 0.36, 4, c);
    cv.quad([[x + s * 0.24, y + s * 0.32], [x + s * 0.52, y + s * 0.08], [x + s * 0.52, y + s * 0.92], [x + s * 0.24, y + s * 0.68]], c);
    if (on) {
        [0.2, 0.34, 0.48].forEach((r, i) => {
            const cx = x + s * 0.56, cy = y + s * 0.5, rr = s * r, pts = [];
            for (let a = -0.9; a <= 0.9001; a += 0.15) pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr]);
            cv.polyline(pts, 5, G.withAlpha(c, 1 - i * 0.25));
        });
    } else {
        cv.line(x + s * 0.64, y + s * 0.34, x + s * 0.92, y + s * 0.66, 6, c);
        cv.line(x + s * 0.92, y + s * 0.34, x + s * 0.64, y + s * 0.66, 6, c);
    }
}

function drawSound(cv, G, t, m, act, bottom) {
    useWidth(cv);
    const y = G.TOP + 10, h = bottom - y;
    // Burbles two thirds of the width, Active Sound one third
    const leftW = Math.round((W - 48 - PE.gap) * 2 / 3), rx = PE.x + leftW + PE.gap, rw = W - 24 - rx;
    const bh = 76, by = y + h - 28 - bh;
    const go = t.go || '#2fd27a', warn = t.warn || '#d29922', ice = t.accent2 || '#81c4ff';
    const noteCol = (m.noteType === 'warn' ? warn : m.noteType === 'go' ? go : t.dim);

    // ---- BURBLES
    card(cv, G, t, PE.x, y, leftW, h, 'BURBLES');
    const lx = PE.x + 32;
    const agg = typeof m.targetAgg === 'number' ? m.targetAgg : 0;
    const aw = cv.text(agg.toFixed(1), lx, y + 170, 120, t.text, { font: 'bold', spacing: 4 });
    cv.text('Aggression 0.0 – 12.0', lx + aw + 24, y + 166, 21, t.dim, { font: 'label' });
    const state = m.burbles === null || m.burbles === undefined ? 'unknown'
        : m.burbles === 'off' ? 'off' : m.burbles === 'custom' ? 'custom value' : m.burbles;
    // its own messages (sent, picked, refused); a problem at the start too; else what the DME has
    const bNote = m.note && (m.noteFeature === 'burbles' || (m.noteFeature === null && m.noteType === 'warn')) ? [m.note, noteCol]
        : ['Now on the DME: ' + state, m.burbles ? go : t.dim];
    cv.text(bNote[0], lx, y + 218, 21, bNote[1], { font: 'label' });
    cardButtons(cv, G, t, lx, leftW - 64, by, bh, [['', act.aggDown, false], ['', act.aggUp, false],
        ['Apply', act.burblesApply, false], ['Off', act.burblesOff, m.burbles === 'off', RED(t)]], m.busy, 'snd_burb');
    // - and + drawn large on their buttons (the button text is sized for words)
    if (cv.own) {
        const bw = (leftW - 64 - 16 * 3) / 4, sc = m.busy ? t.dim : t.text, cy = by + bh / 2;
        cv.fillRect(lx + bw / 2 - 18, cy - 3, 36, 6, sc);
        cv.fillRect(lx + bw + 16 + bw / 2 - 18, cy - 3, 36, 6, sc);
        cv.fillRect(lx + bw + 16 + bw / 2 - 3, cy - 18, 6, 36, sc);
    }

    // ---- ACTIVE SOUND
    card(cv, G, t, rx, y, rw, h, 'ACTIVE SOUND');
    const word = m.asd === true ? 'ON' : m.asd === false ? 'OFF' : '–';
    const acol = m.asd === true ? ice : m.asd === false ? RED(t) : t.dim;
    cv.text(word, rx + rw - 32, y + 46, 24, acol, { align: 'right', font: 'bold', spacing: 1 });
    const s = Math.min(150, by - (y + 70) - 70);
    drawSpeaker(cv, G, t, rx + 40, y + 76, s, m.asd === true, ice);
    cv.text(word, rx + rw - 40, y + 76 + s * 0.5 + 40, 110, acol, { align: 'right', font: 'bold', spacing: 4 });
    const aNote = m.note && m.noteFeature === 'asd' ? [m.note, noteCol]
        : m.asd != null ? ['Last setting accepted by the DME', go] : ['Not sent yet', t.dim];
    cv.text(aNote[0], rx + 32, by - 22, 19, aNote[1], { font: 'label' });
    const a = act.asd || (() => null);
    cardButtons(cv, G, t, rx + 32, rw - 64, by, bh, [['On', a(true), m.asd === true, ice],
        ['Off', a(false), m.asd === false, RED(t)]], m.busy, 'snd_asd');
    return cv;
}

/** "Tuning software" is Off: the page says so, nothing is sent and there is nothing to press. */
function drawOff(cv, G, t, bottom) {
    const cy = G.TOP + (bottom - G.TOP) / 2;
    cv.text('OFF', W / 2, cy - 10, 96, t.dim, { align: 'center', font: 'bold', spacing: 4 });
    cv.text('Tuning software is off · pick ZD8/BM3 in Settings', W / 2, cy + 50, 22, t.dim, { align: 'center', font: 'label' });
    return cv;
}

function draw(cv, G, t, page, m, act) {
    useWidth(cv);
    // the house content panel over the whole content area (reaches the page's bottom: it stretches down
    // where the screen has room below the page, so there is no dark band under it)
    G.panel(cv, t, 24, G.TOP, W - 48, G.BOTTOM - G.TOP, null);
    const bottom = G.pageBottom(cv) - (cv.own ? G.MARGIN : 0);
    if (!m.armed) return drawOff(cv, G, t, bottom);
    if (page === 'burbles') return drawBurbles(cv, G, t, m, act || {}, bottom);
    if (page === 'flap') return drawFlap(cv, G, t, m, act || {}, bottom);
    if (page === 'perf') return drawPerfExhaust(cv, G, t, m, act || {}, bottom);
    if (page === 'sound') return drawSound(cv, G, t, m, act || {}, bottom);
    if (page === 'asd') return drawAsd(cv, G, t, m, act || {}, bottom);
    return drawMap(cv, G, t, m, act || {}, bottom);
}

module.exports = { draw, drawMap, drawBurbles, drawFlap, drawAsd, drawPerfExhaust, drawSound, MAP_NAMES, W };
