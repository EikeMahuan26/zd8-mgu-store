'use strict';
/**
 * gauges_page.js (3.0) - the Gauges page (仪表) as IterioDev's Car Data for iDrive 8, its engine screen (car-apps
 * iteriodev_cardash 1.1.9, reference copies in id8_src/cardash/): the layout and the values, in this app's page.
 *
 *   left   Engine speed and Boost: segmented bars with a 3 s peak hold and a red zone (the last 10 % of the bar);
 *          below them Oil, Coolant, Intake air and Battery
 *   right  Speed + the gear ("D3" in D), Power and Torque: segmented bars, peak hold, red zone
 *
 * Values (as Car Data): rpm, speed, oil, coolant, crankshaft torque and the gear from the car's own signals (this app's
 * one Car, the same scalings), power = torque x rpm (hp); boost and intake air from OBD service 01 to the DME (0x12):
 * boost = the highest fresh absolute pressure of PID 0x70 (boost sensor), 0x87 and 0x0B minus the outside pressure
 * 0x33, intake air = PID 0x0F (obd.js, verbatim: the PID table, several PIDs per request, the supported-PID scan);
 * battery = the head unit's supply voltage (Harman LevelMonitor systemVoltage, instance "Inst1"), its unit picked by
 * size as Car Data does. The OBD requests run only while this page shows (one at a time, read-only service 01) and
 * never while a tune command is on its way; the bar ends are in Settings ("Gauges ·").
 */
const G = require('./kit/gauges');
const { getLanguage } = require('./kit/i18n');
const obd = require('./obd');

const DME = 0x12;
const PEAK_MS = 3000, OBD_GAP_MS = 10, OBD_TIMEOUT_MS = 2000, OBD_FRESH_MS = 5000;
const L = (en, cn) => (getLanguage() === 'zh-CN' ? cn : en);

function create(ctx, car, getLink, isBusy) {
    const { settings, log } = ctx;
    let active = false, pageOn = false, widgetOn = false;
    function update() {
        const on = pageOn || widgetOn;
        if (on === active) return;
        active = on;
        if (on) schedule(0);
        log.info('gauges: OBD ' + (on ? 'on' : 'off') + (on && !pageOn ? ' (home-screen widget)' : ''));
    }

    /* ---------- battery: the head unit's supply voltage ---------- */
    let volt = null, voltAt = 0;
    if (ctx.signals && ctx.signals.watch) {
        ctx.signals.watch('com.harman.infotainment.systeminfrastructure.environment.levelmonitor.LevelMonitor', 'Inst1', {
            systemVoltage: (x) => { if (x && typeof x.value === 'number') { volt = x.value; voltAt = Date.now(); } },
        }, log, { pollMs: 1000 }).then((s) => log.info('gauges: battery voltage ' + (s && s.error ? 'error ' + s.error : 'subscribed')))
            .catch((e) => log.warn('gauges: battery voltage ' + e));
    }
    // the unit isn't documented: mV, 10 mV, 100 mV and V each put 6-16 V in their own range (Car Data's rule)
    const battery = () => {
        if (!(typeof volt === 'number' && volt > 0) || Date.now() - voltAt > 5000) return undefined;
        return volt >= 5000 ? volt / 1000 : volt >= 500 ? volt / 100 : volt >= 50 ? volt / 10 : volt;
    };

    /* ---------- OBD 01 to the DME: boost + intake air (Car Data's request rotation, reduced to what this page shows) ---- */
    const o = {};                       // key -> { value, at } | { err }
    const supported = { scanned: false, pids: null, i: 0 };    // i: the next SUPPORT PID when scanning one at a time
    const refused = new Set();
    let multi = true, pending = false, slowTurn = false, obdTimer = null;
    const obdVal = (k) => (o[k] && 'value' in o[k] ? o[k].value : undefined);
    const obdFresh = (k) => o[k] && 'value' in o[k] && Date.now() - o[k].at < OBD_FRESH_MS;
    const has = (p) => !refused.has(p) && (!supported.pids || supported.pids.indexOf(p) >= 0);
    function nextPids() {
        if (!supported.scanned) return multi ? obd.SUPPORT.slice() : [obd.SUPPORT[supported.i]];
        slowTurn = !slowTurn;
        const noMapX = o.mapX && 'value' in o.mapX && o.mapX.value === undefined;
        const fast = [has(0x70) ? 0x70 : null, has(0x87) && !noMapX ? 0x87 : null, has(0x0B) ? 0x0B : null].filter((p) => p !== null);
        const slow = [0x33, 0x0F].filter(has);
        const list = multi ? fast.concat(slow) : slowTurn && slow.length ? slow : fast;
        if (!list.length) return [];
        return multi ? list.slice(0, 6) : [list[Math.floor(Date.now() / 300) % list.length]];
    }
    async function obdTick() {
        obdTimer = null;
        const link = getLink();
        if (!active || pending || !link || !link.available || !link.diag || isBusy()) { schedule(200); return; }
        const pids = nextPids();
        if (!pids.length) { schedule(1000); return; }
        pending = true;
        try {
            const reply = await link.diag.physical(DME, 0x01, pids, OBD_TIMEOUT_MS,
                (u) => u[0] === 0x41 || (u[0] === 0x7F && u[1] === 0x01), { quiet: true });
            if (!reply) throw new Error('timeout');
            if (reply[0] === 0x7F) throw new Error('NRC 7F 01 ' + reply[2].toString(16).toUpperCase().padStart(2, '0'));
            const ans = obd.parse(reply.slice(1));
            if (!supported.scanned) {
                supported.pids = (supported.pids || []).concat(ans.supported);
                // one bitmap per request: the next one only while the last said "more" (its bit 32 = the next range)
                if (multi || !(supported.pids.indexOf(obd.SUPPORT[supported.i] + 0x20) >= 0) || ++supported.i >= obd.SUPPORT.length) {
                    supported.scanned = true;
                    log.info('gauges: DME OBD PIDs ' + supported.pids.map((x) => x.toString(16).toUpperCase().padStart(2, '0')).join(' '));
                }
            }
            Object.keys(ans.values).forEach((k) => { o[k] = { value: ans.values[k], at: Date.now() }; });
        } catch (e) {
            const m = String(e && e.message || e);
            if (pids.length > 1 && /NRC|timeout/.test(m)) multi = false;                 // one PID per request from now on
            else if (/NRC 7F 01 (12|31)/.test(m)) pids.forEach((p) => refused.add(p));
            else if (!supported.scanned && !(pids.length > 1)) { supported.scanned = true; supported.pids = null; }   // no scan answer: ask anyway
        } finally {
            pending = false;
            schedule(OBD_GAP_MS);
        }
    }
    function schedule(ms) { if (!obdTimer) obdTimer = setTimeout(obdTick, ms); }

    /* ---------- values (metric), the peak hold ---------- */
    const boost = () => {
        const ps = ['boostP', 'mapX', 'map'].filter(obdFresh).map(obdVal).filter((v) => v !== undefined);
        if (ps.length && obdVal('baro') !== undefined) return (Math.max.apply(null, ps) - obdVal('baro')) / 100;
        return undefined;
    };
    const peaks = {};
    function peak(k, v) {
        if (!G.isNum(v)) return undefined;
        const p = peaks[k], now = Date.now();
        if (!p || v >= p.v || now - p.at > PEAK_MS) peaks[k] = { v, at: now };
        return peaks[k].v;
    }
    const rnd = (v, d) => (G.isNum(v) ? +v.toFixed(d || 0) : undefined);
    const red = (k) => +(settings.get(k) * 0.9).toFixed(2);
    function gearShown(d) {
        const st = d.stage, g = d.gear;
        if (st === 'P' || st === 'R' || st === 'N') return st;
        if (G.isNum(g) && g > 0) return (st === 'D' || st === undefined ? 'D' : '') + g;
        if (g === -1) return 'R';
        return st || '-';
    }

    /* ---------- drawing: the engine screen (id8_src/cardash/screens.json), in this page's content area ---------- */
    // left column 24..1056, right 1080..1576 (Car Data: 302..1791 | 1836..2824 of 2880)
    function draw(cv, t) {
        const d = car.data();
        const rpm = rnd(d.rpm), tq = rnd(d.torque), hp = G.isNum(d.torque) && G.isNum(d.rpm) ? rnd(d.torque * d.rpm / 9549.3 * 1.341) : undefined;
        const bst = rnd(boost(), 2);
        // 1600 wide: left 24..1056, right 1080..1576; a wider page (iDrive 8) widens both in that proportion
        const W = cv.w || 1600, k = (W - 72) / 1528;
        const LX = 24, LW = Math.round(1032 * k), RX = LX + LW + 24, RW = W - 24 - RX, top = G.TOP + 4;
        const sc = (every, extra) => Object.assign({ size: 18, every, labelY: 32, tick: 6 }, extra || {});   // the labels clear of the ticks
        G.segBar(cv, t, LX, top, LW, 166, { label: L('Engine speed', '发动机转速'), unit: 'rpm', min: 0, max: settings.get('gRpmMax'), value: rpm,
            decimals: 0, limit: red('gRpmMax'), step: 500, scale: sc(1000, { div: 1000 }), ramp: 'hot', peak: peak('rpm', rpm) });
        G.segBar(cv, t, LX, top + 176, LW, 166, { label: L('Boost', '增压'), unit: 'bar', min: 0, max: settings.get('gBoostMax'), value: bst,
            decimals: 2, limit: red('gBoostMax'), step: 0.125, scale: sc(0.5, { decimals: 1 }), ramp: 'hot', peak: peak('boost', bst) });
        // the four small bars
        const small = [
            [L('Oil', '机油'), '°C', 40, settings.get('gOilMax'), rnd(d.oil), 0],
            [L('Coolant', '冷却液'), '°C', 40, settings.get('gCoolantMax'), rnd(d.coolant), 0],
            [L('Intake air', '进气'), '°C', -20, settings.get('gIntakeMax'), rnd(obdVal('iat')), 0],
            [L('Battery', '电池'), 'V', 10, 16, rnd(battery(), 1), 1],
        ];
        const sw = (LW - 3 * 24) / 4, sy = top + 360;
        small.forEach(([label, unit, min, max, v, dec], i) => {
            G.bar(cv, t, LX + i * (sw + 24), sy, sw, 96, { label, unit, min, max, value: v, decimals: dec, ramp: 'hot' });
        });
        // speed + gear
        G.panel(cv, t, RX, top, RW, 130, L('Speed', '车速'));
        G.readout(cv, t, RX + 24, top + 58, { value: rnd(d.speed), unit: 'km/h', decimals: 0, size: 60 });
        cv.text(gearShown(d), RX + RW - 24, top + 112, 72, t.dim, { align: 'right', font: 'bold' });
        G.segBar(cv, t, RX, top + 140, RW, 158, { label: L('Power', '功率'), unit: 'hp', min: 0, max: settings.get('gPowerMax'), value: hp,
            decimals: 0, limit: red('gPowerMax'), step: settings.get('gPowerMax') > 500 ? 50 : 25, scale: sc(100), ramp: 'hot', peak: peak('hp', hp) });
        G.segBar(cv, t, RX, top + 308, RW, 158, { label: L('Torque', '扭矩'), unit: 'Nm', min: 0, max: settings.get('gTorqueMax'), value: tq,
            decimals: 0, limit: red('gTorqueMax'), step: 50, scale: sc(100), ramp: 'hot', peak: peak('nm', tq) });
    }

    return {
        draw,
        badges() { return [car.data().demo ? { text: 'DEMO' } : null]; },
        /** The page shows (and the screen does): OBD runs; hidden: nothing is sent. */
        setActive(on) { pageOn = !!on; update(); },
        /** 3.2.18: a home-screen widget with Intake air shows (iDrive 8, setting widgetObd): OBD runs too. */
        setWidgetActive(on) { widgetOn = !!on; update(); },
        /** Intake air (OBD PID 0F) while fresh, else undefined. */
        intake() { return obdFresh('iat') ? obdVal('iat') : undefined; },
        get obd() { return o; },
        get supported() { return supported; },
        boost,
        battery,
    };
}

module.exports = { create };
